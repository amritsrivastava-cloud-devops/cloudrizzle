
from fastapi import FastAPI
from app.api.routes import health, projects, ai

app = FastAPI()

app.include_router(health.router)
app.include_router(projects.router, prefix="/projects")
app.include_router(ai.router, prefix="/ai")
