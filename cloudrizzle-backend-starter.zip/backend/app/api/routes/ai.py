from fastapi import APIRouter

router = APIRouter()

@router.post("/generate")
def generate(prompt: str):
    return {"terraform": f"Generated for: {prompt}"}
