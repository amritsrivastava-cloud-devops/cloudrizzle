
STEP 1: Build backend
cd backend
docker build -t cloudrizzle-backend .

STEP 2: Run backend
docker run -d -p 8000:8000 cloudrizzle-backend

STEP 3: Test
http://localhost:8000/health

STEP 4: Connect frontend
In frontend .env.local add:
NEXT_PUBLIC_API_URL=http://<EC2-IP>:8000

Example fetch:
fetch(`${process.env.NEXT_PUBLIC_API_URL}/projects`)
