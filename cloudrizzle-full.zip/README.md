
# Cloudrizzle Full Production

## Run
docker-compose up --build

Frontend: http://localhost
Backend: http://localhost/api/v1/projects
