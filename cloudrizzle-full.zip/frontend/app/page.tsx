
export default function Home() {
  return <h1>Cloudrizzle Full App Running</h1>;
}
