"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useUser, useClerk } from "@clerk/nextjs";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/Alert";

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  badge?: string;
  badgeVariant?: "default" | "blue" | "red" | "green";
}

interface SidebarProps {
  items: { section: string; links: NavItem[] }[];
  isAdmin?: boolean;
}

export function Sidebar({ items, isAdmin }: SidebarProps) {
  const pathname = usePathname();
  const { user } = useUser();
  const { signOut } = useClerk();

  const badgeColors: Record<string, string> = {
    default: "bg-[#1c2640] text-[#8493b8]",
    blue: "bg-blue-400/15 text-blue-400",
    red: "bg-red-400/15 text-red-400",
    green: "bg-green-400/15 text-green-400",
  };

  return (
    <aside className="w-[230px] bg-[#0a0e1a] border-r border-white/5 flex flex-col flex-shrink-0 h-screen overflow-y-auto overflow-x-hidden">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-4 py-[18px] border-b border-white/5 flex-shrink-0">
        <div
          className={cn(
            "w-[30px] h-[30px] rounded-[9px] flex items-center justify-center text-[13px] font-black text-white flex-shrink-0",
            isAdmin
              ? "bg-gradient-to-br from-[#f97316] to-[#c0390a]"
              : "bg-gradient-to-br from-[#4f8ef7] to-[#8b5cf6]"
          )}
        >
          ⚡
        </div>
        <div>
          <div className="text-sm font-black tracking-[-0.03em] text-[#e2e8f8]">CloudRizzle</div>
          <div className={cn("text-[9px] font-mono tracking-[0.05em]", isAdmin ? "text-[#f97316]" : "text-[#4f8ef7]")}>
            {isAdmin ? "admin panel" : "user workspace"}
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2.5 py-3 flex flex-col gap-1">
        {items.map((section) => (
          <div key={section.section} className="mb-4">
            <div className="text-[9px] font-bold text-[#2a3352] uppercase tracking-[0.12em] px-2.5 mb-1">
              {section.section}
            </div>
            {section.links.map((item) => {
              const active = pathname === item.href || pathname.startsWith(item.href + "/");
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-2.5 px-2.5 py-2 rounded-[9px] text-xs font-semibold transition-all duration-150 relative group mb-0.5",
                    active
                      ? isAdmin
                        ? "bg-[#f97316]/10 text-[#f97316]"
                        : "bg-[#4f8ef7]/10 text-[#4f8ef7]"
                      : "text-[#8493b8] hover:bg-[#0f1525] hover:text-[#e2e8f8]"
                  )}
                >
                  {active && (
                    <span
                      className={cn(
                        "absolute left-0 top-1/2 -translate-y-1/2 w-[2.5px] h-[18px] rounded-sm",
                        isAdmin ? "bg-[#f97316]" : "bg-[#4f8ef7]"
                      )}
                    />
                  )}
                  <span className={cn("w-[15px] h-[15px] flex-shrink-0 opacity-80", active && "opacity-100")}>
                    {item.icon}
                  </span>
                  <span className="flex-1">{item.label}</span>
                  {item.badge && (
                    <span className={cn("text-[9px] font-bold px-1.5 py-0.5 rounded-[8px] font-mono", badgeColors[item.badgeVariant || "default"])}>
                      {item.badge}
                    </span>
                  )}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="px-2.5 py-3 border-t border-white/5 flex-shrink-0">
        <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-[10px] bg-[#0f1525] border border-white/5">
          <Avatar
            name={user?.firstName || user?.emailAddresses[0]?.emailAddress || "U"}
            className={cn("w-7 h-7", isAdmin ? "av-r" : "av-b")}
            variant={isAdmin ? "red" : "blue"}
          />
          <div className="flex-1 min-w-0">
            <div className="text-[11px] font-bold text-[#e2e8f8] truncate">
              {user?.firstName
                ? `${user.firstName} ${user.lastName || ""}`.trim()
                : user?.emailAddresses[0]?.emailAddress || "User"}
            </div>
            <div className="text-[9px] font-mono text-[#4a567a]">
              {isAdmin ? "superuser" : "pro · user"}
            </div>
          </div>
          <button
            onClick={() => signOut()}
            className="text-[#4a567a] text-xs hover:text-red-400 transition-colors p-1"
            title="Sign out"
          >
            ✕
          </button>
        </div>
      </div>
    </aside>
  );
}
