import { cn } from "@/lib/utils";

interface AlertProps {
  children: React.ReactNode;
  variant?: "error" | "warning" | "info";
  className?: string;
}

export function Alert({ children, variant = "info", className }: AlertProps) {
  const variants = {
    error: "bg-red-400/6 border-red-400/18 [--dot:theme(colors.red.400)]",
    warning: "bg-amber-400/6 border-amber-400/18 [--dot:theme(colors.amber.400)]",
    info: "bg-blue-400/6 border-blue-400/18 [--dot:theme(colors.blue.400)]",
  };

  const dotColors = {
    error: "bg-red-400",
    warning: "bg-amber-400",
    info: "bg-blue-400",
  };

  return (
    <div className={cn("flex items-start gap-2.5 px-4 py-3 rounded-[11px] border", variants[variant], className)}>
      <div className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0 mt-1 animate-[pulse_1.5s_infinite]", dotColors[variant])} />
      <div className="text-[11px] font-mono text-[#8493b8] leading-relaxed">{children}</div>
    </div>
  );
}

interface MiniBarProps {
  label: string;
  value: number;
  color?: string;
  showVal?: boolean;
}

export function MiniBar({ label, value, color = "#4f8ef7", showVal = true }: MiniBarProps) {
  return (
    <div className="flex items-center gap-2 mb-2">
      <div className="text-[10px] font-mono text-[#8493b8] w-16 flex-shrink-0">{label}</div>
      <div className="flex-1 h-1.5 bg-[#1c2640] rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${value}%`, background: color }}
        />
      </div>
      {showVal && (
        <div className="text-[10px] font-mono text-[#8493b8] w-8 text-right">{value}%</div>
      )}
    </div>
  );
}

export function CostBar({ name, value, maxValue, color = "#4f8ef7" }: { name: string; value: number; maxValue: number; color?: string }) {
  const pct = Math.min((value / maxValue) * 100, 100);
  return (
    <div className="mb-3.5">
      <div className="flex justify-between items-center mb-1.5">
        <span className="text-xs font-semibold text-[#e2e8f8]">{name}</span>
        <span className="text-[11px] font-mono text-[#8493b8]">${value.toLocaleString()}/mo</span>
      </div>
      <div className="h-1 bg-[#1c2640] rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

export function Avatar({ name, className, variant = "blue" }: { name: string; className?: string; variant?: string }) {
  const variants: Record<string, string> = {
    blue: "from-[#4f8ef7] to-[#8b5cf6]",
    red: "from-[#f97316] to-[#c0390a]",
    green: "from-[#10d98a] to-[#14b8a6]",
    violet: "from-[#8b5cf6] to-[#ec4899]",
    amber: "from-[#f59e0b] to-[#f97316]",
    cyan: "from-[#06b6d4] to-[#0284c7]",
  };
  return (
    <div
      className={cn(
        "flex items-center justify-center font-black text-white rounded-[8px] flex-shrink-0 bg-gradient-to-br text-[11px]",
        variants[variant] || variants.blue,
        className
      )}
    >
      {name[0].toUpperCase()}
    </div>
  );
}

export function Tabs({
  tabs,
  active,
  onChange,
}: {
  tabs: { label: string; value: string }[];
  active: string;
  onChange: (val: string) => void;
}) {
  return (
    <div className="flex gap-0.5 bg-[#0f1525] rounded-[10px] p-1 w-fit mb-4">
      {tabs.map((t) => (
        <button
          key={t.value}
          onClick={() => onChange(t.value)}
          className={cn(
            "px-4 py-1.5 rounded-[7px] text-xs font-semibold transition-all",
            active === t.value
              ? "bg-[#0a0e1a] text-[#e2e8f8] shadow-sm"
              : "text-[#8493b8] hover:text-[#e2e8f8]"
          )}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

export function SettingRow({
  label,
  desc,
  children,
}: {
  label: string;
  desc?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between py-3.5 border-b border-white/5 last:border-b-0">
      <div>
        <div className="text-xs font-semibold text-[#e2e8f8]">{label}</div>
        {desc && <div className="text-[10px] font-mono text-[#4a567a] mt-0.5">{desc}</div>}
      </div>
      <div>{children}</div>
    </div>
  );
}

export function SparkBar({ value, max, color = "#4f8ef7" }: { value: number; max: number; color?: string }) {
  const pct = (value / max) * 100;
  return (
    <div className="flex-1 min-w-[6px] rounded-t-sm" style={{ height: `${pct}%`, background: color, opacity: 0.5 + (pct / 200) }} />
  );
}

export function DeployDot({ status }: { status: string }) {
  const colors: Record<string, string> = {
    success: "bg-green-400 shadow-[0_0_8px_rgba(16,217,138,0.5)]",
    active: "bg-green-400 shadow-[0_0_8px_rgba(16,217,138,0.5)]",
    running: "bg-blue-400",
    queued: "bg-violet-400 animate-pulse",
    failed: "bg-red-400",
    error: "bg-red-400",
    pending: "bg-amber-400",
  };
  return (
    <div className={cn("w-2 h-2 rounded-full flex-shrink-0 mt-1", colors[status] || "bg-white/20")} />
  );
}
