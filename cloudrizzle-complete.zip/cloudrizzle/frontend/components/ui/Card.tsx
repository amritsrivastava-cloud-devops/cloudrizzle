import { cn } from "@/lib/utils";

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
}

export function Card({ children, className, hover }: CardProps) {
  return (
    <div
      className={cn(
        "bg-[#0a0e1a] border border-white/5 rounded-[14px] overflow-hidden",
        hover && "transition-all duration-200 hover:border-white/9 hover:-translate-y-0.5 cursor-pointer",
        className
      )}
    >
      {children}
    </div>
  );
}

interface CardHeaderProps {
  title: string;
  action?: React.ReactNode;
  className?: string;
}

export function CardHeader({ title, action, className }: CardHeaderProps) {
  return (
    <div className={cn("flex items-center justify-between px-5 py-3.5 border-b border-white/5", className)}>
      <span className="text-xs font-bold text-[#e2e8f8] tracking-[-0.01em]">{title}</span>
      {action && <div>{action}</div>}
    </div>
  );
}

// Stat Card
interface StatCardProps {
  label: string;
  value: string | number;
  desc?: string;
  icon?: React.ReactNode;
  badge?: string;
  badgeUp?: boolean;
  badgeDown?: boolean;
  color?: "blue" | "green" | "amber" | "red" | "violet" | "cyan" | "orange" | "teal";
  className?: string;
}

const colorMap = {
  blue: { accent: "#4f8ef7", icon: "rgba(79,142,247,0.12)", val: "" },
  green: { accent: "#10d98a", icon: "rgba(16,217,138,0.12)", val: "text-green-400" },
  amber: { accent: "#f59e0b", icon: "rgba(245,158,11,0.12)", val: "" },
  red: { accent: "#ef4444", icon: "rgba(239,68,68,0.12)", val: "text-red-400" },
  violet: { accent: "#8b5cf6", icon: "rgba(139,92,246,0.12)", val: "" },
  cyan: { accent: "#06b6d4", icon: "rgba(6,182,212,0.12)", val: "" },
  orange: { accent: "#f97316", icon: "rgba(249,115,22,0.12)", val: "" },
  teal: { accent: "#14b8a6", icon: "rgba(20,184,166,0.12)", val: "" },
};

export function StatCard({ label, value, desc, icon, badge, badgeUp, badgeDown, color = "blue", className }: StatCardProps) {
  const c = colorMap[color];
  return (
    <div
      className={cn("bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px] relative overflow-hidden transition-all hover:border-white/9 hover:-translate-y-0.5", className)}
      style={{ "--sc": c.accent } as any}
    >
      {/* top accent line */}
      <div className="absolute top-0 left-0 right-0 h-px opacity-50" style={{ background: c.accent }} />
      <div className="flex items-start justify-between mb-3">
        {icon && (
          <div className="w-[34px] h-[34px] rounded-[9px] flex items-center justify-center text-sm" style={{ background: c.icon }}>
            {icon}
          </div>
        )}
        {badge && (
          <span className={cn("font-mono text-[10px] font-bold px-2 py-0.5 rounded-[7px]", badgeUp ? "bg-green-400/10 text-green-400" : badgeDown ? "bg-red-400/10 text-red-400" : "bg-white/5 text-white/40")}>
            {badge}
          </span>
        )}
      </div>
      <div className="text-[10px] font-semibold text-[#8493b8] uppercase tracking-[0.07em] mb-1">{label}</div>
      <div className={cn("text-[28px] font-black tracking-[-0.05em] leading-none", c.val)}>{value}</div>
      {desc && <div className="text-[10px] text-[#4a567a] font-mono mt-1.5">{desc}</div>}
    </div>
  );
}
