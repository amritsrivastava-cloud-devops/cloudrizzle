import { cn } from "@/lib/utils";

interface BadgeProps {
  children: React.ReactNode;
  variant?: "default" | "blue" | "green" | "amber" | "red" | "violet" | "cyan" | "ghost";
  className?: string;
}

export function Badge({ children, variant = "default", className }: BadgeProps) {
  const variants = {
    default: "bg-white/5 text-white/40",
    blue: "bg-blue-400/10 text-blue-400",
    green: "bg-green-400/10 text-green-400",
    amber: "bg-amber-400/10 text-amber-400",
    red: "bg-red-400/10 text-red-400",
    violet: "bg-violet-400/10 text-violet-400",
    cyan: "bg-cyan-400/10 text-cyan-400",
    ghost: "bg-white/5 text-white/30",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center font-mono text-[9px] font-bold px-2 py-0.5 rounded-full tracking-wide whitespace-nowrap",
        variants[variant],
        className
      )}
    >
      {children}
    </span>
  );
}

// Cloud badge
export function CloudBadge({ cloud }: { cloud: string }) {
  const config: Record<string, { label: string; className: string }> = {
    aws: { label: "AWS", className: "bg-amber-400/10 text-amber-400" },
    azure: { label: "Azure", className: "bg-cyan-400/10 text-cyan-400" },
    gcp: { label: "GCP", className: "bg-green-400/10 text-green-400" },
  };
  const c = config[cloud] || { label: cloud.toUpperCase(), className: "bg-white/5 text-white/40" };
  return (
    <span className={cn("inline-flex items-center font-mono text-[9px] font-bold px-1.5 py-0.5 rounded tracking-wide", c.className)}>
      {c.label}
    </span>
  );
}

// Status pill
export function StatusPill({ status }: { status: string }) {
  const config: Record<string, string> = {
    active: "bg-green-400/10 text-green-400",
    running: "bg-green-400/10 text-green-400",
    success: "bg-green-400/10 text-green-400",
    available: "bg-green-400/10 text-green-400",
    healthy: "bg-green-400/10 text-green-400",
    published: "bg-green-400/10 text-green-400",
    connected: "bg-green-400/10 text-green-400",
    error: "bg-red-400/10 text-red-400",
    failed: "bg-red-400/10 text-red-400",
    degraded: "bg-red-400/10 text-red-400",
    suspended: "bg-red-400/10 text-red-400",
    queued: "bg-blue-400/10 text-blue-400",
    new: "bg-blue-400/10 text-blue-400",
    pending: "bg-amber-400/10 text-amber-400",
    stopped: "bg-white/5 text-white/30",
    draft: "bg-white/5 text-white/40",
    disconnected: "bg-white/5 text-white/40",
  };

  return (
    <span className={cn("inline-flex items-center font-mono text-[9px] font-bold px-2 py-0.5 rounded-full tracking-wide whitespace-nowrap", config[status] || "bg-white/5 text-white/40")}>
      {status}
    </span>
  );
}

// Plan pill
export function PlanBadge({ plan }: { plan: string }) {
  const config: Record<string, string> = {
    free: "bg-white/5 text-white/40",
    pro: "bg-blue-400/10 text-blue-400",
    enterprise: "bg-violet-400/10 text-violet-400",
  };
  return (
    <span className={cn("inline-flex items-center font-mono text-[9px] font-bold px-2 py-0.5 rounded-full tracking-wide", config[plan] || "bg-white/5 text-white/40")}>
      {plan}
    </span>
  );
}
