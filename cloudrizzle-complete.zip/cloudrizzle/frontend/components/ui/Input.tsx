import { cn } from "@/lib/utils";
import { InputHTMLAttributes, TextareaHTMLAttributes, forwardRef } from "react";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, ...props }, ref) => {
    return (
      <div className="flex flex-col gap-1.5 w-full">
        {label && (
          <label className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.07em]">
            {label}
          </label>
        )}
        <input
          ref={ref}
          className={cn(
            "bg-[#0f1525] border border-white/9 rounded-[11px] px-3.5 py-3 text-[13px] text-[#e2e8f8] outline-none transition-all placeholder:text-[#4a567a]",
            "focus:border-[#4f8ef7] focus:bg-[#151d32]",
            error && "border-red-400/50",
            className
          )}
          {...props}
        />
        {error && <span className="text-[11px] text-red-400 font-mono">{error}</span>}
      </div>
    );
  }
);
Input.displayName = "Input";

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, label, ...props }, ref) => {
    return (
      <div className="flex flex-col gap-1.5 w-full">
        {label && (
          <label className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.07em]">
            {label}
          </label>
        )}
        <textarea
          ref={ref}
          className={cn(
            "bg-transparent border-none text-[#e2e8f8] font-mono text-xs outline-none resize-none placeholder:text-[#4a567a] leading-relaxed w-full",
            className
          )}
          {...props}
        />
      </div>
    );
  }
);
Textarea.displayName = "Textarea";

interface SelectProps {
  label?: string;
  value: string;
  onChange: (val: string) => void;
  options: { label: string; value: string }[];
  className?: string;
}

export function Select({ label, value, onChange, options, className }: SelectProps) {
  return (
    <div className="flex flex-col gap-1.5 w-full">
      {label && (
        <label className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.07em]">
          {label}
        </label>
      )}
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={cn(
          "bg-[#0f1525] border border-white/9 rounded-[11px] px-3.5 py-3 text-[13px] text-[#e2e8f8] outline-none transition-all cursor-pointer appearance-none",
          "focus:border-[#4f8ef7]",
          className
        )}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value} className="bg-[#0f1525]">
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}

interface ToggleProps {
  checked: boolean;
  onChange: (val: boolean) => void;
  admin?: boolean;
}

export function Toggle({ checked, onChange, admin }: ToggleProps) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={cn(
        "relative w-9 h-5 rounded-full transition-colors duration-200 flex-shrink-0",
        checked
          ? admin
            ? "bg-[#f97316]"
            : "bg-[#4f8ef7]"
          : "bg-[#1c2640]"
      )}
    >
      <span
        className={cn(
          "absolute top-[3px] w-3.5 h-3.5 bg-white rounded-full shadow transition-transform duration-200",
          checked ? "translate-x-[18px]" : "translate-x-[3px]"
        )}
      />
    </button>
  );
}

interface SearchInputProps extends InputHTMLAttributes<HTMLInputElement> {
  onSearch?: (val: string) => void;
}

export function SearchInput({ className, onSearch, ...props }: SearchInputProps) {
  return (
    <input
      className={cn(
        "bg-[#0f1525] border border-white/9 rounded-[9px] px-3 py-2 text-xs text-[#e2e8f8] outline-none transition-all placeholder:text-[#4a567a] w-[200px]",
        "focus:border-[#4f8ef7] focus:w-[240px]",
        className
      )}
      onChange={(e) => onSearch?.(e.target.value)}
      {...props}
    />
  );
}
