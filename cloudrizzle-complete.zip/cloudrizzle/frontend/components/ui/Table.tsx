import { cn } from "@/lib/utils";

interface TableProps {
  headers: string[];
  children: React.ReactNode;
  className?: string;
}

export function Table({ headers, children, className }: TableProps) {
  return (
    <div className={cn("overflow-x-auto", className)}>
      <table className="w-full border-collapse">
        <thead>
          <tr>
            {headers.map((h) => (
              <th
                key={h}
                className="px-[18px] py-2.5 text-left text-[9px] font-bold text-[#4a567a] tracking-[0.1em] uppercase border-b border-white/5 bg-[#0f1525] font-mono whitespace-nowrap"
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

interface TrProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
}

export function Tr({ children, onClick, className }: TrProps) {
  return (
    <tr
      className={cn(
        "border-b border-white/5 last:border-b-0 transition-colors",
        onClick && "cursor-pointer hover:bg-white/[0.015]",
        className
      )}
      onClick={onClick}
    >
      {children}
    </tr>
  );
}

interface TdProps {
  children: React.ReactNode;
  className?: string;
  main?: boolean;
}

export function Td({ children, className, main }: TdProps) {
  return (
    <td
      className={cn(
        "px-[18px] py-3 text-[11px] font-mono align-middle",
        main ? "text-[#e2e8f8] font-bold font-sans text-xs" : "text-[#8493b8]",
        className
      )}
    >
      {children}
    </td>
  );
}

// Convenience cell with main + sub text
export function TdUser({ name, sub, avatar }: { name: string; sub: string; avatar?: React.ReactNode }) {
  return (
    <td className="px-[18px] py-3 align-middle">
      <div className="flex items-center gap-2">
        {avatar}
        <div>
          <div className="text-xs font-bold text-[#e2e8f8]">{name}</div>
          <div className="text-[10px] text-[#4a567a] font-mono mt-0.5">{sub}</div>
        </div>
      </div>
    </td>
  );
}

export function TdMain({ main, sub }: { main: string; sub?: string }) {
  return (
    <td className="px-[18px] py-3 align-middle">
      <div className="text-xs font-bold text-[#e2e8f8]">{main}</div>
      {sub && <div className="text-[10px] text-[#4a567a] font-mono mt-0.5">{sub}</div>}
    </td>
  );
}
