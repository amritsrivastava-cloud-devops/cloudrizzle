import { useQuery } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";

export function useCostSummary() {
  return useQuery({
    queryKey: ["costs", "summary"],
    queryFn: async () => {
      const { data } = await apiClient.get("/costs/summary");
      return data;
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useCostsByProject() {
  return useQuery({
    queryKey: ["costs", "by-project"],
    queryFn: async () => {
      const { data } = await apiClient.get("/costs/by-project");
      return data;
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useCostsByProvider() {
  return useQuery({
    queryKey: ["costs", "by-provider"],
    queryFn: async () => {
      const { data } = await apiClient.get("/costs/by-provider");
      return data;
    },
    staleTime: 5 * 60 * 1000,
  });
}
