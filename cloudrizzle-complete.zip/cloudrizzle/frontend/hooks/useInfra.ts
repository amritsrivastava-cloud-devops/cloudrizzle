import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";

export function useInfraResources(projectId: string) {
  return useQuery({
    queryKey: ["infra", "resources", projectId],
    queryFn: async () => {
      const { data } = await apiClient.get(`/infra/${projectId}/resources`);
      return data;
    },
    enabled: !!projectId,
  });
}

export function usePlanInfra(projectId: string) {
  return useMutation({
    mutationFn: async (terraform: string) => {
      const { data } = await apiClient.post(`/infra/${projectId}/plan`, {
        terraform,
      });
      return data;
    },
  });
}

export function useApplyInfra(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (planId: string) => {
      const { data } = await apiClient.post(`/infra/${projectId}/apply`, {
        plan_id: planId,
      });
      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["projects"] });
      qc.invalidateQueries({ queryKey: ["deployments"] });
      qc.invalidateQueries({ queryKey: ["infra", "resources", projectId] });
    },
  });
}

export function useDestroyInfra(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const { data } = await apiClient.post(`/infra/${projectId}/destroy`);
      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["projects"] });
    },
  });
}
