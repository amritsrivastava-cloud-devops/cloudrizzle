import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";

const KEYS = {
  all: ["cloud-accounts"] as const,
};

export function useCloudAccounts() {
  return useQuery({
    queryKey: KEYS.all,
    queryFn: async () => {
      const { data } = await apiClient.get("/cloud-accounts");
      return data;
    },
  });
}

export function useConnectCloud() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: {
      provider: string;
      name: string;
      account_id: string;
      region: string;
      access_type: string;
      credentials: Record<string, string>;
    }) => {
      const { data } = await apiClient.post("/cloud-accounts", payload);
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEYS.all }),
  });
}

export function useTestCloudConnection() {
  return useMutation({
    mutationFn: async (accountId: string) => {
      const { data } = await apiClient.post(
        `/cloud-accounts/${accountId}/test`
      );
      return data;
    },
  });
}

export function useDisconnectCloud() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (accountId: string) => {
      await apiClient.delete(`/cloud-accounts/${accountId}`);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEYS.all }),
  });
}
