import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";
import type { Project } from "@/types";

const KEYS = {
  all: ["projects"] as const,
  list: (filters?: Record<string, string>) => ["projects", "list", filters] as const,
  detail: (id: string) => ["projects", id] as const,
};

// ─── Fetch all projects ───────────────────────────────────────
export function useProjects(filters?: { cloud?: string; status?: string }) {
  return useQuery({
    queryKey: KEYS.list(filters),
    queryFn: async (): Promise<Project[]> => {
      const { data } = await apiClient.get("/projects", { params: filters });
      return data;
    },
  });
}

// ─── Fetch single project ─────────────────────────────────────
export function useProject(id: string) {
  return useQuery({
    queryKey: KEYS.detail(id),
    queryFn: async (): Promise<Project> => {
      const { data } = await apiClient.get(`/projects/${id}`);
      return data;
    },
    enabled: !!id,
  });
}

// ─── Create project ───────────────────────────────────────────
export function useCreateProject() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: {
      name: string;
      cloud: string;
      environment: string;
      description?: string;
    }) => {
      const { data } = await apiClient.post("/projects", payload);
      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: KEYS.all });
    },
  });
}

// ─── Update project ───────────────────────────────────────────
export function useUpdateProject(id: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: Partial<Project>) => {
      const { data } = await apiClient.put(`/projects/${id}`, payload);
      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: KEYS.all });
      qc.invalidateQueries({ queryKey: KEYS.detail(id) });
    },
  });
}

// ─── Delete project ───────────────────────────────────────────
export function useDeleteProject() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      await apiClient.delete(`/projects/${id}`);
      return id;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: KEYS.all });
    },
  });
}
