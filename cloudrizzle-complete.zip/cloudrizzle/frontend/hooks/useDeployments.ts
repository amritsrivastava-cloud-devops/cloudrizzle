import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";
import type { Deployment } from "@/types";

const KEYS = {
  all: ["deployments"] as const,
  list: (projectId?: string) => ["deployments", "list", projectId] as const,
  detail: (id: string) => ["deployments", id] as const,
  logs: (id: string) => ["deployments", id, "logs"] as const,
};

export function useDeployments(projectId?: string) {
  return useQuery({
    queryKey: KEYS.list(projectId),
    queryFn: async (): Promise<Deployment[]> => {
      const { data } = await apiClient.get("/deployments", {
        params: projectId ? { project_id: projectId } : undefined,
      });
      return data;
    },
    // Poll every 10s when there are running deployments
    refetchInterval: (query) => {
      const deployments = query.state.data as Deployment[] | undefined;
      const hasRunning = deployments?.some(
        (d) => d.status === "running" || d.status === "queued"
      );
      return hasRunning ? 10000 : false;
    },
  });
}

export function useDeployment(id: string) {
  return useQuery({
    queryKey: KEYS.detail(id),
    queryFn: async (): Promise<Deployment> => {
      const { data } = await apiClient.get(`/deployments/${id}`);
      return data;
    },
    enabled: !!id,
    // Poll while running
    refetchInterval: (query) => {
      const d = query.state.data as Deployment | undefined;
      return d?.status === "running" || d?.status === "queued" ? 5000 : false;
    },
  });
}

export function useDeploymentLogs(id: string) {
  return useQuery({
    queryKey: KEYS.logs(id),
    queryFn: async () => {
      const { data } = await apiClient.get(`/deployments/${id}/logs`);
      return data;
    },
    enabled: !!id,
    refetchInterval: 5000,
  });
}
