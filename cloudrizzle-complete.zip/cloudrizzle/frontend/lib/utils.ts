import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatNumber(num: number): string {
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}k`;
  return num.toString();
}

export function timeAgo(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

export function truncate(str: string, maxLength: number): string {
  if (str.length <= maxLength) return str;
  return str.slice(0, maxLength) + "...";
}

export const cloudLabels: Record<string, string> = {
  aws: "AWS",
  azure: "Azure",
  gcp: "GCP",
};

export const cloudColors: Record<string, string> = {
  aws: "text-amber-400 bg-amber-400/10",
  azure: "text-cyan-400 bg-cyan-400/10",
  gcp: "text-green-400 bg-green-400/10",
};

export const statusColors: Record<string, string> = {
  active: "text-green-400 bg-green-400/10",
  running: "text-green-400 bg-green-400/10",
  success: "text-green-400 bg-green-400/10",
  available: "text-green-400 bg-green-400/10",
  error: "text-red-400 bg-red-400/10",
  failed: "text-red-400 bg-red-400/10",
  degraded: "text-red-400 bg-red-400/10",
  suspended: "text-red-400 bg-red-400/10",
  queued: "text-blue-400 bg-blue-400/10",
  pending: "text-amber-400 bg-amber-400/10",
  stopped: "text-white/20 bg-white/5",
};
