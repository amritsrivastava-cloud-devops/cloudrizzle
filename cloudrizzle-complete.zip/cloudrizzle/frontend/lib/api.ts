import axios from "axios";

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000",
  headers: { "Content-Type": "application/json" },
});

// Attach Clerk token to every request
api.interceptors.request.use(async (config) => {
  if (typeof window !== "undefined") {
    try {
      const { getToken } = await import("@clerk/nextjs/server");
      // Token is attached via Clerk's useAuth on client side
    } catch {}
  }
  return config;
});

// ─── Projects ─────────────────────────────────────────────────
export const projectsApi = {
  list: () => api.get("/api/v1/projects"),
  get: (id: string) => api.get(`/api/v1/projects/${id}`),
  create: (data: any) => api.post("/api/v1/projects", data),
  update: (id: string, data: any) => api.put(`/api/v1/projects/${id}`, data),
  delete: (id: string) => api.delete(`/api/v1/projects/${id}`),
};

// ─── Deployments ───────────────────────────────────────────────
export const deploymentsApi = {
  list: (projectId?: string) =>
    api.get("/api/v1/deployments", { params: { projectId } }),
  get: (id: string) => api.get(`/api/v1/deployments/${id}`),
  getLogs: (id: string) => api.get(`/api/v1/deployments/${id}/logs`),
};

// ─── AI Generator ──────────────────────────────────────────────
export const aiApi = {
  generate: (data: {
    prompt: string;
    cloud: string;
    environment: string;
    model: string;
  }) => api.post("/api/v1/ai/generate", data),
  validate: (terraform: string) =>
    api.post("/api/v1/ai/validate", { terraform }),
  estimateCost: (terraform: string) =>
    api.post("/api/v1/ai/estimate-cost", { terraform }),
};

// ─── Infra ─────────────────────────────────────────────────────
export const infraApi = {
  plan: (projectId: string, terraform: string) =>
    api.post(`/api/v1/infra/${projectId}/plan`, { terraform }),
  apply: (projectId: string, planId: string) =>
    api.post(`/api/v1/infra/${projectId}/apply`, { planId }),
  destroy: (projectId: string) =>
    api.post(`/api/v1/infra/${projectId}/destroy`),
  resources: (projectId: string) =>
    api.get(`/api/v1/infra/${projectId}/resources`),
};

// ─── Cloud Accounts ────────────────────────────────────────────
export const cloudApi = {
  list: () => api.get("/api/v1/cloud-accounts"),
  connect: (data: any) => api.post("/api/v1/cloud-accounts", data),
  test: (id: string) => api.post(`/api/v1/cloud-accounts/${id}/test`),
  disconnect: (id: string) => api.delete(`/api/v1/cloud-accounts/${id}`),
};

// ─── Templates ─────────────────────────────────────────────────
export const templatesApi = {
  list: (cloud?: string) =>
    api.get("/api/v1/templates", { params: { cloud } }),
  get: (id: string) => api.get(`/api/v1/templates/${id}`),
};

// ─── Monitoring ────────────────────────────────────────────────
export const monitoringApi = {
  metrics: (projectId: string, range: string) =>
    api.get(`/api/v1/monitoring/${projectId}/metrics`, { params: { range } }),
  logs: (projectId: string) =>
    api.get(`/api/v1/monitoring/${projectId}/logs`),
  uptime: () => api.get("/api/v1/monitoring/uptime"),
};

// ─── Costs ─────────────────────────────────────────────────────
export const costsApi = {
  summary: () => api.get("/api/v1/costs/summary"),
  byProject: () => api.get("/api/v1/costs/by-project"),
  byProvider: () => api.get("/api/v1/costs/by-provider"),
};

// ─── Admin ─────────────────────────────────────────────────────
export const adminApi = {
  users: {
    list: (params?: any) => api.get("/api/v1/admin/users", { params }),
    get: (id: string) => api.get(`/api/v1/admin/users/${id}`),
    suspend: (id: string) => api.post(`/api/v1/admin/users/${id}/suspend`),
    unsuspend: (id: string) =>
      api.post(`/api/v1/admin/users/${id}/unsuspend`),
  },
  projects: {
    list: (params?: any) => api.get("/api/v1/admin/projects", { params }),
  },
  deployments: {
    list: (params?: any) =>
      api.get("/api/v1/admin/deployments", { params }),
  },
  infra: {
    resources: (params?: any) =>
      api.get("/api/v1/admin/infra/resources", { params }),
  },
  templates: {
    list: () => api.get("/api/v1/admin/templates"),
    create: (data: any) => api.post("/api/v1/admin/templates", data),
    update: (id: string, data: any) =>
      api.put(`/api/v1/admin/templates/${id}`, data),
    delete: (id: string) => api.delete(`/api/v1/admin/templates/${id}`),
  },
  monitoring: {
    platform: () => api.get("/api/v1/admin/monitoring/platform"),
    logs: () => api.get("/api/v1/admin/monitoring/logs"),
  },
  revenue: {
    summary: () => api.get("/api/v1/admin/revenue/summary"),
  },
};

export default api;
