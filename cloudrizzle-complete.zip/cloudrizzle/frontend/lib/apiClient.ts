import axios, { AxiosInstance, AxiosError } from "axios";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

// Create axios instance
export const apiClient: AxiosInstance = axios.create({
  baseURL: `${BASE_URL}/api/v1`,
  headers: { "Content-Type": "application/json" },
  timeout: 30000,
});

// Attach Clerk token to every request
apiClient.interceptors.request.use(async (config) => {
  try {
    // Clerk exposes getToken on the window object in the browser
    if (typeof window !== "undefined") {
      const { Clerk } = window as any;
      if (Clerk?.session) {
        const token = await Clerk.session.getToken();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
      }
    }
  } catch {
    // No token — let the request go through unauthenticated
  }
  return config;
});

// Global error handler
apiClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      // Redirect to sign-in on 401
      if (typeof window !== "undefined") {
        window.location.href = "/sign-in";
      }
    }
    return Promise.reject(error);
  }
);

export default apiClient;
