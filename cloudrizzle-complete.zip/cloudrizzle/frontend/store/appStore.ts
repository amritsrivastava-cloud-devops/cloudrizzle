import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Project, CloudAccount, GenerationResult } from "@/types";

// ─── App Store ────────────────────────────────────────────────
interface AppStore {
  // Sidebar
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;

  // Active project
  activeProjectId: string | null;
  setActiveProject: (id: string | null) => void;

  // Cloud accounts
  cloudAccounts: CloudAccount[];
  setCloudAccounts: (accounts: CloudAccount[]) => void;

  // AI Generation
  generationResult: GenerationResult | null;
  setGenerationResult: (result: GenerationResult | null) => void;
  generationLoading: boolean;
  setGenerationLoading: (loading: boolean) => void;

  // Prompt
  prompt: string;
  setPrompt: (prompt: string) => void;
  selectedCloud: string;
  setSelectedCloud: (cloud: string) => void;
  selectedModel: string;
  setSelectedModel: (model: string) => void;
  selectedEnv: string;
  setSelectedEnv: (env: string) => void;
}

export const useAppStore = create<AppStore>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      toggleSidebar: () =>
        set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),

      activeProjectId: null,
      setActiveProject: (id) => set({ activeProjectId: id }),

      cloudAccounts: [],
      setCloudAccounts: (accounts) => set({ cloudAccounts: accounts }),

      generationResult: null,
      setGenerationResult: (result) => set({ generationResult: result }),
      generationLoading: false,
      setGenerationLoading: (loading) => set({ generationLoading: loading }),

      prompt: "",
      setPrompt: (prompt) => set({ prompt }),
      selectedCloud: "aws",
      setSelectedCloud: (cloud) => set({ selectedCloud: cloud }),
      selectedModel: "claude-3.5-sonnet",
      setSelectedModel: (model) => set({ selectedModel: model }),
      selectedEnv: "production",
      setSelectedEnv: (env) => set({ selectedEnv: env }),
    }),
    {
      name: "cloudrizzle-store",
      partialize: (state) => ({
        sidebarCollapsed: state.sidebarCollapsed,
        selectedCloud: state.selectedCloud,
        selectedModel: state.selectedModel,
        selectedEnv: state.selectedEnv,
      }),
    }
  )
);
