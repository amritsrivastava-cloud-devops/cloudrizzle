import { Topbar } from "@/components/layout/Topbar";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Table, Tr, Td, TdMain } from "@/components/ui/Table";
import { CloudBadge, StatusPill } from "@/components/ui/Badge";

const projects = [
  { name: "Production VPC Stack", desc: "EC2 + RDS + ALB", owner: "Rahul Dev", cloud: "aws", resources: 8, env: "prod", cost: 340, last: "2h ago", status: "active" },
  { name: "Enterprise Data Platform", desc: "BigQuery + Dataflow + Pub/Sub", owner: "Arjun Mehta", cloud: "gcp", resources: 24, env: "prod", cost: 4200, last: "1h ago", status: "active" },
  { name: "Multi-Region Load Balancer", desc: "AWS + Cloudflare + WAF", owner: "Vikram Singh", cloud: "aws", resources: 16, env: "prod", cost: 1840, last: "30m ago", status: "active" },
  { name: "Microservices AKS", desc: "Azure Kubernetes + ACR", owner: "Sneha Patel", cloud: "azure", resources: 12, env: "staging", cost: 890, last: "2d ago", status: "error" },
  { name: "GCP Cloud Run API", desc: "Cloud Run + Cloud SQL", owner: "Kavita Nair", cloud: "gcp", resources: 5, env: "dev", cost: 112, last: "3d ago", status: "active" },
  { name: "S3 Marketing Site", desc: "S3 + CloudFront", owner: "Priya Sharma", cloud: "aws", resources: 3, env: "prod", cost: 12, last: "5d ago", status: "active" },
];

export default function AdminProjectsPage() {
  return (
    <>
      <Topbar title="All Projects" crumb="admin / projects" onSearch={() => {}} actions={<Button variant="ghost" size="sm">Export</Button>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">All Projects</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">4,821 projects across all users and 3 cloud providers</p>
        </div>
        <Card>
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/5">
            <span className="text-xs font-bold">Platform-wide Projects</span>
            <div className="flex gap-1.5">
              <Button variant="ghost" size="sm" className="text-[10px] py-1 px-2.5">All Clouds</Button>
              <Button variant="ghost" size="sm" className="text-[10px] py-1 px-2.5">All Status</Button>
            </div>
          </div>
          <Table headers={["Project", "Owner", "Cloud", "Resources", "Env", "Monthly Cost", "Last Deploy", "Status"]}>
            {projects.map((p) => (
              <Tr key={p.name}>
                <TdMain main={p.name} sub={p.desc} />
                <Td>{p.owner}</Td>
                <Td><CloudBadge cloud={p.cloud} /></Td>
                <Td>{p.resources}</Td>
                <Td>{p.env}</Td>
                <Td className={p.cost > 2000 ? "text-amber-400" : ""}>${p.cost.toLocaleString()}</Td>
                <Td>{p.last}</Td>
                <Td><StatusPill status={p.status} /></Td>
              </Tr>
            ))}
          </Table>
        </Card>
      </div>
    </>
  );
}
