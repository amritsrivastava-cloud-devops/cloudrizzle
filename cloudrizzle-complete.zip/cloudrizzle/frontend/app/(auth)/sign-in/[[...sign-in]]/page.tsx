import { SignIn } from "@clerk/nextjs";

export default function SignInPage() {
  return (
    <div className="flex flex-col items-center gap-8">
      {/* Brand */}
      <div className="flex items-center gap-3">
        <div className="w-11 h-11 rounded-[13px] bg-gradient-to-br from-[#4f8ef7] to-[#8b5cf6] flex items-center justify-center text-xl shadow-[0_8px_24px_rgba(79,142,247,0.35)]">
          ⚡
        </div>
        <div>
          <div className="text-xl font-black tracking-[-0.04em] text-[#e2e8f8]">CloudRizzle</div>
          <div className="text-[10px] font-mono text-[#4f8ef7] tracking-[0.06em]">AI Infrastructure Platform</div>
        </div>
      </div>
      <SignIn
        appearance={{
          elements: {
            rootBox: "w-[420px]",
            card: "bg-[#0a0e1a] border border-white/9 rounded-[24px] shadow-[0_32px_80px_rgba(0,0,0,0.6)] p-10",
            headerTitle: "text-[26px] font-black tracking-[-0.04em] text-[#e2e8f8]",
            headerSubtitle: "text-[13px] text-[#8493b8]",
            formFieldLabel: "text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.07em]",
            formFieldInput:
              "bg-[#0f1525] border border-white/9 rounded-[11px] text-[13px] text-[#e2e8f8] focus:border-[#4f8ef7] focus:ring-0",
            formButtonPrimary:
              "bg-gradient-to-r from-[#4f8ef7] to-[#6366f1] hover:opacity-90 text-sm font-bold rounded-[11px] shadow-[0_8px_24px_rgba(79,142,247,0.3)]",
            footerActionLink: "text-[#4f8ef7] font-semibold hover:opacity-80",
            dividerLine: "bg-white/9",
            dividerText: "text-[#4a567a] font-mono text-[11px]",
            socialButtonsBlockButton:
              "bg-[#0f1525] border border-white/9 text-[#8493b8] hover:bg-[#151d32] rounded-[11px]",
            socialButtonsBlockButtonText: "text-[#8493b8] text-sm",
          },
        }}
      />
    </div>
  );
}
