import { Topbar } from "@/components/layout/Topbar";
import { StatCard, Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { CostBar, MiniBar, Alert } from "@/components/ui/Alert";

const projects = [
  { name: "Microservices AKS", cost: 890, color: "#ef4444" },
  { name: "Production VPC Stack", cost: 340, color: "#f59e0b" },
  { name: "GCP Cloud Run API", cost: 112, color: "#4f8ef7" },
  { name: "aws deploy server ec2", cost: 62, color: "#4f8ef7" },
  { name: "S3 Static Website", cost: 8, color: "#10d98a" },
];

export default function CostsPage() {
  const maxCost = Math.max(...projects.map(p => p.cost));
  return (
    <>
      <Topbar title="Cost Tracking" crumb="workspace / costs" actions={<><Button variant="ghost" size="sm">Apr 2025</Button><Button variant="ghost" size="sm">Export CSV</Button></>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Cost Tracking</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Real-time cloud spend across all providers</p>
        </div>
        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="This Month" value="$1,412" desc="Apr 1 – Apr 3" icon="💰" badge="+3%" badgeDown color="amber" />
          <StatCard label="Last Month" value="$1,371" desc="March 2025" icon="📅" badge="—" color="blue" />
          <StatCard label="Budget" value="$2,000" desc="71% used · $588 left" icon="🎯" badge="on track" badgeUp color="green" />
          <StatCard label="Month Forecast" value="$1,580" desc="Based on current usage" icon="🔮" badge="est." color="violet" />
        </div>
        <div className="grid grid-cols-[1fr_280px] gap-4">
          <Card>
            <CardHeader title="Spend by Project" />
            <div className="p-4">
              {projects.map((p) => (
                <CostBar key={p.name} name={p.name} value={p.cost} maxValue={maxCost} color={p.color} />
              ))}
            </div>
          </Card>
          <div>
            <Card className="mb-3">
              <CardHeader title="By Provider" />
              <div className="p-4">
                <MiniBar label="AWS" value={29} color="#f59e0b" />
                <MiniBar label="Azure" value={63} color="#06b6d4" />
                <MiniBar label="GCP" value={8} color="#10d98a" />
              </div>
            </Card>
            <Alert variant="warning">AKS is 63% of total spend — consider right-sizing nodes</Alert>
          </div>
        </div>
      </div>
    </>
  );
}
