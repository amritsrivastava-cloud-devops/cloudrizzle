import { Topbar } from "@/components/layout/Topbar";
import { Button } from "@/components/ui/Button";
import { Avatar } from "@/components/ui/Alert";
import { StatusPill, PlanBadge } from "@/components/ui/Badge";

export default function ProfilePage() {
  return (
    <>
      <Topbar title="Profile" crumb="workspace / profile" actions={<Button variant="ghost" size="sm">Edit Profile</Button>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Profile</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Manage your account and subscription</p>
        </div>

        {/* Banner */}
        <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-6 flex items-center gap-5 mb-4">
          <Avatar name="R" variant="blue" className="w-16 h-16 rounded-[17px] text-2xl" />
          <div>
            <div className="text-xl font-black tracking-[-0.03em]">Rahul Dev</div>
            <div className="text-xs font-mono text-[#8493b8] mt-1">rahul@dev.com</div>
            <div className="flex gap-2 mt-2">
              <PlanBadge plan="pro" />
              <StatusPill status="active" />
            </div>
          </div>
          <div className="ml-auto text-right">
            <div className="text-[11px] font-mono text-[#4a567a]">Next billing</div>
            <div className="text-sm font-bold text-[#e2e8f8] mt-0.5">May 1, 2025</div>
            <div className="text-[11px] font-mono text-[#8493b8] mt-0.5">$29/month</div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          {/* Account details */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] overflow-hidden">
            <div className="px-5 py-3.5 border-b border-white/5 text-xs font-bold">Account Details</div>
            <div className="grid grid-cols-2 gap-3.5 p-4">
              {[
                ["Name", "Rahul Dev"],
                ["Email", "rahul@dev.com"],
                ["Plan", "Pro"],
                ["Joined", "Jan 2025"],
                ["2FA", "Enabled"],
                ["Timezone", "Asia/Kolkata"],
              ].map(([k, v]) => (
                <div key={k}>
                  <div className="text-[9px] font-mono text-[#4a567a] uppercase tracking-[0.08em] mb-1">{k}</div>
                  <div className={`text-[13px] font-semibold ${k === "2FA" ? "text-green-400" : "text-[#e2e8f8]"}`}>{v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Usage */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] overflow-hidden">
            <div className="px-5 py-3.5 border-b border-white/5 text-xs font-bold">Plan Usage</div>
            <div className="grid grid-cols-2 gap-3.5 p-4">
              {[
                ["Projects", "5 / ∞"],
                ["Deployments", "10 / ∞"],
                ["AI Credits", "840 / 1,000"],
                ["Team Members", "1 / 5"],
                ["Cloud Accounts", "3 / 10"],
                ["Templates", "Unlimited"],
              ].map(([k, v]) => (
                <div key={k}>
                  <div className="text-[9px] font-mono text-[#4a567a] uppercase tracking-[0.08em] mb-1">{k}</div>
                  <div className={`text-[13px] font-semibold ${k === "AI Credits" ? "text-amber-400" : "text-[#e2e8f8]"}`}>{v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* API Keys */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] overflow-hidden">
            <div className="px-5 py-3.5 border-b border-white/5 text-xs font-bold">API Access</div>
            <div className="p-4 flex flex-col gap-3">
              <div>
                <div className="text-[9px] font-mono text-[#4a567a] uppercase tracking-[0.08em] mb-1.5">API Key</div>
                <div className="flex gap-2">
                  <input
                    readOnly
                    value="cr_live_••••••••••••••••"
                    className="flex-1 bg-[#0f1525] border border-white/9 rounded-[9px] px-3 py-2 text-[11px] font-mono text-[#8493b8]"
                  />
                  <Button variant="ghost" size="sm" className="text-[10px] px-2.5">Copy</Button>
                </div>
              </div>
              <div>
                <div className="text-[9px] font-mono text-[#4a567a] uppercase tracking-[0.08em] mb-1.5">Webhook URL</div>
                <div className="flex gap-2">
                  <input
                    readOnly
                    value="https://api.cloudrizzle.com/wh/..."
                    className="flex-1 bg-[#0f1525] border border-white/9 rounded-[9px] px-3 py-2 text-[11px] font-mono text-[#8493b8]"
                  />
                  <Button variant="ghost" size="sm" className="text-[10px] px-2.5">Copy</Button>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="w-full justify-center text-[11px] mt-1">
                Regenerate API Key
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
