"use client";

import { useCallback } from "react";
import ReactFlow, {
  Node, Edge, Background, Controls, MiniMap,
  BackgroundVariant, useNodesState, useEdgesState,
} from "reactflow";
import "reactflow/dist/style.css";
import { Topbar } from "@/components/layout/Topbar";
import { Button } from "@/components/ui/Button";
import { StatusPill } from "@/components/ui/Badge";

const InfraNode = ({ data }: { data: any }) => (
  <div className="bg-[#0a0e1a] border border-white/9 rounded-[11px] px-3.5 py-2.5 min-w-[140px] cursor-grab hover:border-white/14 transition-colors">
    <div className="text-[8px] font-mono text-[#4a567a] uppercase tracking-[0.08em] mb-1">{data.type}</div>
    <div className="text-xs font-bold text-[#e2e8f8]">{data.label}</div>
    <div className="flex items-center gap-1.5 mt-1.5">
      <div className={`w-[5px] h-[5px] rounded-full ${data.statusColor}`} />
      <div className="text-[9px] font-mono text-[#4a567a]">{data.status}</div>
    </div>
  </div>
);

const nodeTypes = { infra: InfraNode };

const initialNodes: Node[] = [
  { id: "igw", type: "infra", position: { x: 60, y: 100 }, data: { label: "Internet Gateway", type: "entry point", status: "igw-0ab12345ef", statusColor: "bg-green-400" } },
  { id: "alb", type: "infra", position: { x: 60, y: 210 }, data: { label: "ALB · Public", type: "load balancer", status: "active · healthy", statusColor: "bg-green-400 animate-pulse" } },
  { id: "ec2-1", type: "infra", position: { x: 290, y: 120 }, data: { label: "EC2 · t3.medium", type: "compute · aws", status: "i-0a1b2c · running", statusColor: "bg-green-400" } },
  { id: "ec2-2", type: "infra", position: { x: 290, y: 220 }, data: { label: "EC2 · t3.medium", type: "compute · aws", status: "i-0b2c3d · running", statusColor: "bg-green-400" } },
  { id: "rds", type: "infra", position: { x: 520, y: 90 }, data: { label: "RDS PostgreSQL", type: "database · aws", status: "db.t3.medium · available", statusColor: "bg-blue-400" } },
  { id: "s3", type: "infra", position: { x: 520, y: 200 }, data: { label: "S3 Bucket", type: "storage · aws", status: "my-app-assets", statusColor: "bg-amber-400" } },
  { id: "sg", type: "infra", position: { x: 520, y: 310 }, data: { label: "Security Group", type: "security · aws", status: "sg-0c3d4e · 3 rules", statusColor: "bg-red-400" } },
  { id: "nat", type: "infra", position: { x: 60, y: 320 }, data: { label: "NAT Gateway", type: "network · aws", status: "nat-0d4e5f · active", statusColor: "bg-teal-400" } },
];

const initialEdges: Edge[] = [
  { id: "igw-ec2-1", source: "igw", target: "ec2-1", style: { stroke: "rgba(79,142,247,0.3)", strokeDasharray: "5 3" } },
  { id: "alb-ec2-2", source: "alb", target: "ec2-2", style: { stroke: "rgba(79,142,247,0.3)", strokeDasharray: "5 3" } },
  { id: "ec2-1-rds", source: "ec2-1", target: "rds", style: { stroke: "rgba(16,217,138,0.25)", strokeDasharray: "5 3" } },
  { id: "ec2-1-s3", source: "ec2-1", target: "s3", style: { stroke: "rgba(79,142,247,0.25)", strokeDasharray: "5 3" } },
  { id: "ec2-2-sg", source: "ec2-2", target: "sg", style: { stroke: "rgba(245,158,11,0.25)", strokeDasharray: "5 3" } },
];

export default function CanvasPage() {
  const [nodes, , onNodesChange] = useNodesState(initialNodes);
  const [edges, , onEdgesChange] = useEdgesState(initialEdges);

  return (
    <>
      <Topbar
        title="Infra Canvas"
        crumb="workspace / canvas"
        actions={
          <>
            <Button variant="ghost" size="sm">Export Terraform</Button>
            <Button variant="ghost" size="sm">Save Layout</Button>
            <Button variant="primary" size="sm">Deploy Changes</Button>
          </>
        }
      />
      <div className="flex-1 overflow-hidden p-5">
        <div className="h-full bg-[#0f1525] border border-white/5 rounded-[14px] overflow-hidden relative">
          {/* VPC label */}
          <div className="absolute top-3 left-3 z-10 text-[9px] font-mono text-white/12 tracking-[0.05em] pointer-events-none">
            VPC · 10.0.0.0/16 · us-east-1 · Production VPC Stack
          </div>
          {/* Inspector panel */}
          <div className="absolute right-4 top-4 z-10 w-[190px] bg-[#0a0e1a] border border-white/9 rounded-[12px] p-3.5">
            <div className="text-[9px] font-bold text-[#8493b8] uppercase tracking-[0.06em] mb-2.5">Node Inspector</div>
            {[
              ["Type", "EC2 Instance"],
              ["ID", "i-0a1b2c3d"],
              ["Size", "t3.medium"],
              ["Region", "us-east-1a"],
              ["State", "running"],
              ["CPU", "24%"],
              ["Cost", "$30.24/mo"],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between mb-1.5">
                <span className="text-[10px] font-mono text-[#4a567a]">{k}</span>
                <span className={`text-[10px] font-mono text-[#e2e8f8] ${k === "State" ? "text-green-400" : ""}`}>{v}</span>
              </div>
            ))}
            <div className="flex gap-1.5 mt-3 pt-2.5 border-t border-white/5">
              <button className="flex-1 py-1.5 text-[10px] font-bold text-[#8493b8] border border-white/9 rounded-[7px] hover:bg-[#0f1525] transition-colors">SSH</button>
              <button className="flex-1 py-1.5 text-[10px] font-bold text-red-400 bg-red-400/10 border border-red-400/20 rounded-[7px] hover:bg-red-400/15 transition-colors">Stop</button>
            </div>
          </div>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            nodeTypes={nodeTypes}
            fitView
            attributionPosition="bottom-left"
          >
            <Background variant={BackgroundVariant.Dots} gap={24} size={1} color="rgba(255,255,255,0.04)" />
            <Controls showInteractive={false} />
            <MiniMap
              nodeColor={() => "#1c2640"}
              maskColor="rgba(6,8,16,0.8)"
              style={{ background: "#0a0e1a" }}
            />
          </ReactFlow>
        </div>
      </div>
    </>
  );
}
