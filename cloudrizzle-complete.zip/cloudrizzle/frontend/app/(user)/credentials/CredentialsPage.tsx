import { Topbar } from "@/components/layout/Topbar";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { StatusPill } from "@/components/ui/Badge";
import { Plus } from "lucide-react";

const clouds = [
  { name: "Amazon Web Services", icon: "☁", iconBg: "bg-amber-400/12", status: "connected", accountId: "123456789012", region: "us-east-1", accessType: "IAM Role", projects: 3, cost: 410, lastSync: "2 min ago" },
  { name: "Microsoft Azure", icon: "☁", iconBg: "bg-cyan-400/12", status: "connected", accountId: "f47b3a2c-...", region: "eastus", accessType: "Service Principal", projects: 1, cost: 890, lastSync: "5 min ago" },
  { name: "Google Cloud Platform", icon: "☁", iconBg: "bg-green-400/12", status: "connected", accountId: "my-gcp-project-id", region: "us-central1", accessType: "Service Account", projects: 1, cost: 112, lastSync: "8 min ago" },
];

export default function CredentialsPage() {
  return (
    <>
      <Topbar title="Cloud Accounts" crumb="workspace / cloud-accounts" actions={<Button variant="primary" size="sm"><Plus size={12} /> Connect Cloud</Button>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Cloud Accounts</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Manage your cloud provider connections</p>
        </div>
        {clouds.map((c) => (
          <div key={c.name} className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px] mb-3">
            <div className="flex items-center gap-3 mb-4">
              <div className={`w-[38px] h-[38px] rounded-[10px] flex items-center justify-center text-lg ${c.iconBg}`}>{c.icon}</div>
              <div>
                <div className="text-sm font-bold text-[#e2e8f8]">{c.name}</div>
                <div className="text-[10px] font-mono text-green-400 mt-0.5">● Connected · {c.accessType}</div>
              </div>
              <div className="ml-auto flex gap-2">
                <Button variant="ghost" size="sm">Test Connection</Button>
                <Button variant="ghost" size="sm">Edit</Button>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2.5">
              {[
                ["Account ID", c.accountId],
                ["Region", c.region],
                ["Access Type", c.accessType],
                ["Projects", `${c.projects} project${c.projects > 1 ? "s" : ""}`],
                ["Monthly Cost", `$${c.cost}/mo`],
                ["Last Sync", c.lastSync],
              ].map(([k, v]) => (
                <div key={k} className="bg-[#0f1525] rounded-[8px] p-2.5">
                  <div className="text-[9px] font-mono text-[#4a567a] uppercase tracking-[0.06em] mb-1">{k}</div>
                  <div className="text-[11px] font-mono text-[#e2e8f8] font-medium">{v}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
