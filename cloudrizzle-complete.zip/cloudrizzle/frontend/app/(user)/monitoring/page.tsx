import { Topbar } from "@/components/layout/Topbar";
import { StatCard } from "@/components/ui/Card";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { MiniBar, Alert } from "@/components/ui/Alert";

const sparkValues = [30, 45, 38, 52, 71, 60, 48, 42, 35, 40, 34];
const memValues = [50, 55, 53, 57, 60, 62, 59, 56, 58, 57, 58];

const uptimeData = Array.from({ length: 90 }, (_, i) => {
  if (i === 6 || i === 26) return "warn";
  if (i === 29) return "error";
  return "ok";
});

const logs = [
  { ts: "14:32:01", lvl: "INFO", msg: "EC2 i-0a1b2c health check passed" },
  { ts: "14:31:58", lvl: "INFO", msg: "ALB target registered successfully" },
  { ts: "14:31:44", lvl: "WARN", msg: "RDS storage at 74% — consider scaling" },
  { ts: "14:31:32", lvl: "INFO", msg: "Auto-scaling group: no action needed" },
  { ts: "14:30:17", lvl: "ERROR", msg: "S3 bucket CORS policy mismatch" },
  { ts: "14:29:55", lvl: "INFO", msg: "CloudFront distribution updated" },
  { ts: "14:28:40", lvl: "INFO", msg: "Certificate renewed via ACM" },
];

const lvlColor: Record<string, string> = {
  INFO: "text-blue-400",
  WARN: "text-amber-400",
  ERROR: "text-red-400",
};

const dotClass: Record<string, string> = {
  ok: "bg-green-400/90",
  warn: "bg-amber-400",
  error: "bg-red-400",
};

export default function MonitoringPage() {
  return (
    <>
      <Topbar
        title="Monitoring"
        crumb="workspace / monitoring"
        actions={
          <>
            <Button variant="ghost" size="sm">Last 24h</Button>
            <Button variant="ghost" size="sm">Refresh</Button>
          </>
        }
      />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Monitoring</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Real-time metrics for your infrastructure</p>
        </div>

        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="Uptime" value="99.9%" desc="Last 30 days" icon="✅" badge="live" color="green" />
          <StatCard label="API Response" value="142ms" desc="avg p95 response" icon="⚡" badge="fast" badgeUp color="blue" />
          <StatCard label="Error Rate" value="0.3%" desc="Last 1 hour" icon="⚠️" badge="watch" badgeDown color="amber" />
          <StatCard label="Requests/min" value="2,841" desc="Peak: 4,200" icon="📊" badge="stable" color="violet" />
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          {/* CPU */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">CPU Usage — All Instances</span>
              <span className="text-[11px] font-semibold text-green-400">Live</span>
            </div>
            <div className="text-[28px] font-black tracking-[-0.04em] text-[#4f8ef7]">34%</div>
            <div className="text-[10px] font-mono text-[#4a567a] mb-3">avg · peak 71% at 14:22</div>
            <div className="flex items-end gap-0.5 h-12">
              {sparkValues.map((v, i) => (
                <div key={i} className="flex-1 rounded-t-sm min-w-[6px]" style={{ height: `${v}%`, background: "#4f8ef7", opacity: 0.4 + v / 200 }} />
              ))}
            </div>
          </div>

          {/* Memory */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">Memory Usage</span>
              <span className="text-[11px] font-semibold text-amber-400">Moderate</span>
            </div>
            <div className="text-[28px] font-black tracking-[-0.04em] text-amber-400">58%</div>
            <div className="text-[10px] font-mono text-[#4a567a] mb-3">3.7GB / 8GB used</div>
            <div className="flex items-end gap-0.5 h-12">
              {memValues.map((v, i) => (
                <div key={i} className="flex-1 rounded-t-sm min-w-[6px]" style={{ height: `${v}%`, background: "#f59e0b", opacity: 0.4 + v / 200 }} />
              ))}
            </div>
          </div>

          {/* Network */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">Network I/O</span>
              <span className="text-[11px] font-semibold text-green-400">Normal</span>
            </div>
            <div className="flex gap-5 mb-3">
              <div><div className="text-[11px] font-mono text-[#4a567a]">In</div><div className="text-xl font-black text-green-400">124 MB/s</div></div>
              <div><div className="text-[11px] font-mono text-[#4a567a]">Out</div><div className="text-xl font-black text-[#4f8ef7]">89 MB/s</div></div>
            </div>
            <MiniBar label="↓ In" value={62} color="#10d98a" />
            <MiniBar label="↑ Out" value={44} color="#4f8ef7" />
          </div>

          {/* Disk */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-4">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">Disk Usage</span>
              <span className="text-[11px] font-semibold text-[#4f8ef7]">Normal</span>
            </div>
            <MiniBar label="i-0a1b2c" value={41} color="#4f8ef7" />
            <MiniBar label="i-0b2c3d" value={38} color="#4f8ef7" />
            <MiniBar label="RDS" value={74} color="#f59e0b" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* Uptime */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">Uptime — Last 90 days</span>
              <span className="text-[11px] font-semibold text-green-400">99.2%</span>
            </div>
            <div className="flex gap-0.5 flex-wrap">
              {uptimeData.map((s, i) => (
                <div key={i} className={`w-2.5 h-2.5 rounded-[3px] ${dotClass[s]}`} />
              ))}
            </div>
            <div className="flex gap-3 mt-2.5">
              {[["bg-green-400/90", "healthy"], ["bg-amber-400", "degraded"], ["bg-red-400", "outage"]].map(([c, l]) => (
                <div key={l} className="flex items-center gap-1.5">
                  <div className={`w-2 h-2 rounded-[2px] ${c}`} />
                  <span className="text-[9px] font-mono text-[#4a567a]">{l}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Logs */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">Live Logs</span>
              <span className="text-[11px] font-semibold text-green-400">Streaming</span>
            </div>
            <div className="bg-[#0f1525] rounded-[8px] p-2.5 max-h-[180px] overflow-y-auto">
              {logs.map((l, i) => (
                <div key={i} className="flex gap-2.5 py-1.5 border-b border-white/5 last:border-b-0 text-[10px] font-mono">
                  <span className="text-[#4a567a] flex-shrink-0 w-[72px]">{l.ts}</span>
                  <span className={`flex-shrink-0 w-10 ${lvlColor[l.lvl]}`}>{l.lvl}</span>
                  <span className="text-[#8493b8]">{l.msg}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
