import { Topbar } from "@/components/layout/Topbar";
import { StatCard } from "@/components/ui/Card";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { CloudBadge, StatusPill } from "@/components/ui/Badge";
import { DeployDot, Alert } from "@/components/ui/Alert";
import { AiPromptBox } from "@/components/dashboard/AiPromptBox";
import { Plus } from "lucide-react";

const projects = [
  { id: "1", name: "Production VPC Stack", meta: "AWS · EC2 + RDS + LB · updated 2h ago", status: "active", cloud: "aws", cost: "$340/mo", icon: "⚡", iconBg: "bg-blue-400/12" },
  { id: "2", name: "aws deploy server ec2", meta: "AWS · EC2 t3.medium · updated 5h ago", status: "active", cloud: "aws", cost: "$62/mo", icon: "◈", iconBg: "bg-green-400/12" },
  { id: "3", name: "S3 Static Website", meta: "AWS · S3 + CloudFront · updated 1d ago", status: "queued", cloud: "aws", cost: "$8/mo", icon: "▲", iconBg: "bg-amber-400/12" },
  { id: "4", name: "Microservices AKS", meta: "Azure · AKS · updated 2d ago", status: "error", cloud: "azure", cost: "$890/mo", icon: "◎", iconBg: "bg-violet-400/12" },
  { id: "5", name: "GCP Cloud Run API", meta: "GCP · Cloud Run + SQL · updated 3d ago", status: "active", cloud: "gcp", cost: "$112/mo", icon: "◆", iconBg: "bg-teal-400/12" },
];

const deployments = [
  { name: "Production VPC Stack", meta: "production · #987688", status: "queued", time: "Dec 19, 04:37" },
  { name: "Static Site + CDN", meta: "development · +12 changes", status: "success", time: "Dec 17, 07:21" },
  { name: "aws deploy server", meta: "production · v1.0.1", status: "success", time: "Dec 12, 09:08" },
  { name: "Microservices AKS", meta: "production · v1.0.0", status: "failed", time: "Dec 11, 08:04" },
  { name: "RDS PostgreSQL", meta: "staging · v2.1.0", status: "success", time: "Dec 10, 14:22" },
  { name: "GCP Cloud Run", meta: "production · v3.0.0", status: "pending", time: "Dec 09, 11:30" },
];

export default function DashboardPage() {
  return (
    <>
      <Topbar
        title="Dashboard"
        crumb="workspace / overview"
        onSearch={() => {}}
        actions={
          <Button variant="primary" size="sm">
            <Plus size={12} /> New Project
          </Button>
        }
      />
      <div className="flex-1 overflow-y-auto p-7">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-[22px] font-black tracking-[-0.04em] text-[#e2e8f8]">
              Welcome back, Rahul 👋
            </h1>
            <p className="text-xs font-mono text-[#8493b8] mt-1">
              Your infrastructure at a glance · Thursday, Apr 3 2025
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="Active Projects" value="5" desc="10 total across 3 clouds" icon="📦" badge="+52%" badgeUp color="blue" />
          <StatCard label="Deployments" value="10" desc="This month" icon="🚀" badge="+8%" badgeUp color="green" />
          <StatCard label="Monthly Cost" value="$1,412" desc="Across all providers" icon="💰" badge="+3%" badgeDown color="amber" />
          <StatCard label="System Health" value="99%" desc="All systems operational" icon="✅" badge="stable" color="green" />
        </div>

        {/* 2 col layout */}
        <div className="grid grid-cols-[1fr_300px] gap-4">
          {/* Left */}
          <div>
            {/* AI Prompt */}
            <AiPromptBox />

            {/* Projects */}
            <Card>
              <CardHeader
                title="My Projects"
                action={<a href="/projects" className="text-[11px] text-[#4f8ef7] font-mono hover:opacity-70 cursor-pointer">view all →</a>}
              />
              {projects.map((p) => (
                <div key={p.id} className="flex items-center gap-3 px-5 py-3 border-b border-white/5 last:border-b-0 hover:bg-[#0f1525] cursor-pointer transition-colors">
                  <div className={`w-[34px] h-[34px] rounded-[9px] flex items-center justify-center text-sm flex-shrink-0 ${p.iconBg}`}>
                    {p.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-[#e2e8f8] truncate">{p.name}</div>
                    <div className="text-[10px] font-mono text-[#4a567a] mt-0.5">{p.meta}</div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <StatusPill status={p.status} />
                    <span className="text-[10px] font-mono text-[#8493b8]">{p.cost}</span>
                  </div>
                </div>
              ))}
            </Card>
          </div>

          {/* Right: Deployments */}
          <Card className="h-fit">
            <CardHeader
              title="Recent Deployments"
              action={<a href="/deployments" className="text-[11px] text-[#4f8ef7] font-mono hover:opacity-70 cursor-pointer">view all →</a>}
            />
            {deployments.map((d, i) => (
              <div key={i} className="flex items-start gap-3 px-5 py-3 border-b border-white/5 last:border-b-0 hover:bg-[#0f1525] cursor-pointer transition-colors">
                <DeployDot status={d.status} />
                <div className="flex-1">
                  <div className="text-xs font-semibold text-[#e2e8f8]">{d.name}</div>
                  <div className="text-[10px] font-mono text-[#4a567a] mt-0.5 leading-relaxed">
                    {d.meta}<br />
                    <StatusPill status={d.status} /> · {d.time}
                  </div>
                </div>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </>
  );
}
