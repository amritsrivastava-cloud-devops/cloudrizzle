
"use client";

import ReactFlow from "reactflow";
import "reactflow/dist/style.css";

const nodes = [
  { id: "1", position: { x: 0, y: 0 }, data: { label: "VPC" } },
  { id: "2", position: { x: 200, y: 100 }, data: { label: "EC2" } },
];

export default function FlowCanvas() {
  return <div style={{ height: 400 }}><ReactFlow nodes={nodes} /></div>;
}
