"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardHeader } from "@/components/ui/Card";
import { useAppStore } from "@/store/appStore";

const QUICK_PROMPTS: Record<string, string> = {
  "AWS VPC + EC2 + RDS": "Create a production 3-tier AWS VPC in us-east-1 with:\n- Application Load Balancer in public subnet\n- 2x EC2 t3.medium instances with Auto Scaling\n- RDS PostgreSQL 15 (db.t3.medium) Multi-AZ with daily backups\n- S3 bucket for assets with CloudFront CDN"},
  "Azure AKS Cluster": "Deploy an Azure Kubernetes Service cluster with:\n- 3-node system pool (Standard_D2s_v3)\n- Azure Container Registry\n- Azure Monitor workspace\n- Key Vault for secrets management\n- NGINX Ingress controller",
  "GCP Cloud Run + SQL": "Create a serverless GCP setup with:\n- Cloud Run service (2 vCPU, 1GB)\n- Cloud SQL PostgreSQL 14\n- VPC connector for private networking\n- Cloud Armor WAF protection",
  "S3 Static Website": "Set up AWS S3 static website hosting with:\n- S3 bucket with versioning and encryption\n- CloudFront distribution with SSL\n- Route53 DNS with custom domain\n- ACM certificate",
  "Multi-cloud LB": "Design a multi-cloud active-passive setup:\n- AWS as primary (VPC + EC2 + ALB)\n- Azure as backup (VNet + VM + LB)\n- Route53 health check failover\n- Encrypted VPN tunnel between clouds"};

export function AiPromptBox() {
  const router = useRouter();
  const { prompt, setPrompt } = useAppStore();
  const [localPrompt, setLocalPrompt] = useState(prompt);

  const handleGenerate = () => {
    setPrompt(localPrompt);
    router.push("/generate");
  };

  return (
    <Card className="mb-4">
      <CardHeader
        title="AI Infra Generator"
        action={<a href="/generate" className="text-[11px] text-[#4f8ef7] font-mono hover:opacity-70 cursor-pointer">view examples →</a>}
      />
      <div className="p-4">
        <div className="bg-[#0f1525] border border-white/9 rounded-[12px] p-3.5 transition-all focus-within:border-[#4f8ef7] focus-within:bg-[#151d32]">
          <textarea
            className="w-full bg-transparent border-none text-[#e2e8f8] font-mono text-xs outline-none resize-none placeholder:text-[#4a567a] leading-relaxed min-h-[80px]"
            placeholder={"Describe your infrastructure...\ne.g. 'Create a 3-tier AWS VPC with load balancer, 2 EC2 t3.medium instances, RDS PostgreSQL with read replica'"}
            value={localPrompt}
            onChange={(e) => setLocalPrompt(e.target.value)}
          />
          <div className="flex items-center gap-2 mt-2.5">
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-[#4a567a]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#10d98a] animate-pulse" />
              claude-3.5-sonnet
            </div>
            <button
              onClick={handleGenerate}
              className="ml-auto px-4 py-2 bg-gradient-to-r from-[#4f8ef7] to-[#6366f1] text-white text-xs font-bold rounded-[8px] transition-all hover:-translate-y-0.5 hover:shadow-[0_8px_20px_rgba(79,142,247,0.45)] shadow-[0_4px_12px_rgba(79,142,247,0.3)]"
            >
              ⚡ Generate Terraform
            </button>
          </div>
        </div>
      </div>
      {/* Quick templates */}
      <div className="flex gap-1.5 flex-wrap px-4 pb-3.5">
        {Object.keys(QUICK_PROMPTS).map((label) => (
          <button
            key={label}
            onClick={() => setLocalPrompt(QUICK_PROMPTS[label])}
            className="text-[10px] font-mono text-[#8493b8] border border-white/9 rounded-[7px] px-2.5 py-1 hover:border-[#4f8ef7] hover:text-[#4f8ef7] hover:bg-[#4f8ef7]/6 transition-all"
          >
            {label}
          </button>
        ))}
      </div>
      {/* Canvas placeholder */}
      <div className="mx-4 mb-4 border border-white/9 border-dashed rounded-[12px] bg-[#0f1525] h-[200px] flex flex-col items-center justify-center gap-2 text-[#4a567a] text-xs font-mono">
        <span className="text-3xl opacity-25" style={{ animation: "float 3s ease-in-out infinite" }>⬡</span>
        <span>Infra canvas — generated resources appear here as interactive nodes</span>
      </div>
    </Card>
  );
}
