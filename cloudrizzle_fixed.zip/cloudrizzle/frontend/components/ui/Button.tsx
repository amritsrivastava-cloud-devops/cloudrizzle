import { cn } from "@/lib/utils";
import { ButtonHTMLAttributes, forwardRef } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "ghost" | "admin" | "danger" | "success";
  size?: "sm" | "md" | "lg";
  loading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "ghost", size = "sm", loading, children, disabled, ...props }, ref) => {
    const variants = {
      primary: "bg-[#4f8ef7] text-white hover:bg-[#3a7ae0] shadow-[0_4px_12px_rgba(79,142,247,0.25)] hover:shadow-[0_8px_20px_rgba(79,142,247,0.4)]"},
      ghost: "bg-transparent text-[#8493b8] border border-white/9 hover:text-[#e2e8f8] hover:border-white/14 hover:bg-[#0f1525]",
      admin: "bg-[#f97316] text-white hover:bg-[#ea6800] shadow-[0_4px_12px_rgba(249,115,22,0.25)]",
      danger: "bg-red-400/10 text-red-400 border border-red-400/20 hover:bg-red-400/15",
      success: "bg-green-400/10 text-green-400 border border-green-400/20 hover:bg-green-400/15"};

    const sizes = {
      sm: "px-3 py-1.5 text-xs"},
      md: "px-4 py-2 text-sm",
      lg: "px-6 py-2.5 text-sm"};

    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex items-center gap-1.5 font-bold rounded-[9px] transition-all duration-150 whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"},
          variants[variant],
          sizes[size],
          className
        )}
        disabled={disabled || loading}
        {...props}
      >
        {loading ? (
          <>
            <svg className="animate-spin w-3 h-3" viewBox="0 0 24 24" fill="none">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
            Loading...
          </>
        ) : children}
      </button>
    );
  }
);

Button.displayName = "Button";
