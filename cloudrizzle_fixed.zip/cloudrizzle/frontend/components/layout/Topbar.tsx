"use client";

import { cn } from "@/lib/utils";
import { SearchInput } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";

interface TopbarProps {
  title: string;
  crumb?: string;
  actions?: React.ReactNode;
  onSearch?: (val: string) => void;
  isAdmin?: boolean;
}

export function Topbar({ title, crumb, actions, onSearch, isAdmin }: TopbarProps) {
  return (
    <div className="h-[54px] bg-[#0a0e1a] border-b border-white/5 flex items-center px-6 gap-3.5 flex-shrink-0">
      <div className="text-sm font-bold tracking-[-0.02em] text-[#e2e8f8]">{title}</div>
      {crumb && (
        <>
          <div className="w-px h-4 bg-white/9" />
          <div className="text-[11px] text-[#4a567a] font-mono">{crumb}</div>
        </>
      )}
      <div className="ml-auto flex items-center gap-2">
        {onSearch && (
          <SearchInput placeholder="Search..." onSearch={onSearch} />
        )}
        {actions}
      </div>
    </div>
  );
}
