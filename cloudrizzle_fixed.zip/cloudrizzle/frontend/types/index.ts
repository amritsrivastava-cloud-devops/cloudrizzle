// ─── User Types ───────────────────────────────────────────────
export type UserRole = "user" | "admin";
export type PlanType = "free" | "pro" | "enterprise";
export type UserStatus = "active" | "suspended" | "pending";

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: UserRole;
  plan: PlanType;
  status: UserStatus;
  createdAt: string;
  lastActive: string;
  cloudAccounts: CloudProvider[];
}

// ─── Cloud Types ───────────────────────────────────────────────
export type CloudProvider = "aws" | "azure" | "gcp";
export type ResourceStatus = "running" | "stopped" | "error" | "pending" | "active" | "available" | "degraded";
export type Environment = "production" | "staging" | "development";

export interface CloudAccount {
  id: string;
  provider: CloudProvider;
  accountId: string;
  name: string;
  region: string;
  status: "connected" | "disconnected" | "error";
  accessType: string;
  monthlyCost: number;
  projectCount: number;
  lastSync: string;
}

// ─── Project Types ─────────────────────────────────────────────
export type ProjectStatus = "active" | "error" | "queued" | "stopped";

export interface Project {
  id: string;
  name: string;
  description?: string;
  cloud: CloudProvider;
  environment: Environment;
  status: ProjectStatus;
  resourceCount: number;
  monthlyCost: number;
  lastDeployedAt: string;
  createdAt: string;
  userId: string;
  terraformState?: string;
}

// ─── Deployment Types ──────────────────────────────────────────
export type DeploymentStatus = "success" | "failed" | "queued" | "running" | "pending";

export interface Deployment {
  id: string;
  projectId: string;
  projectName: string;
  cloud: CloudProvider;
  version: string;
  environment: Environment;
  status: DeploymentStatus;
  duration?: string;
  triggeredBy: string;
  createdAt: string;
  logs?: string[];
  error?: string;
}

// ─── Infra Resource Types ──────────────────────────────────────
export interface InfraResource {
  id: string;
  resourceId: string;
  type: string;
  name: string;
  cloud: CloudProvider;
  region: string;
  projectId: string;
  projectName: string;
  userId: string;
  status: ResourceStatus;
  monthlyCost: number;
  createdAt: string;
  metadata?: Record<string, string>;
}

// ─── Template Types ────────────────────────────────────────────
export type TemplateStatus = "published" | "draft" | "archived";
export type TemplateCategory =
  | "networking"
  | "compute"
  | "serverless"
  | "kubernetes"
  | "database"
  | "storage"
  | "security"
  | "disaster-recovery"
  | "monitoring";

export interface Template {
  id: string;
  name: string;
  description: string;
  cloud: CloudProvider | "multi";
  category: TemplateCategory;
  resources: string[];
  status: TemplateStatus;
  usageCount: number;
  successRate: number;
  updatedAt: string;
  isPopular?: boolean;
  isNew?: boolean;
  terraformCode?: string;
}

// ─── AI Generation Types ───────────────────────────────────────
export interface GenerationRequest {
  prompt: string;
  cloud: CloudProvider;
  environment: Environment;
  model: string;
}

export interface GenerationResult {
  id: string;
  terraform: string;
  resources: string[];
  estimatedCost: number;
  validationPassed: boolean;
  warnings: string[];
}

// ─── Monitoring Types ──────────────────────────────────────────
export interface MetricPoint {
  timestamp: string;
  value: number;
}

export interface Metrics {
  cpu: MetricPoint[];
  memory: MetricPoint[];
  network: { in: MetricPoint[]; out: MetricPoint[] };
  disk: MetricPoint[];
  requests: MetricPoint[];
  errors: MetricPoint[];
}

export interface UptimeDay {
  date: string;
  status: "healthy" | "degraded" | "outage";
}

// ─── Cost Types ────────────────────────────────────────────────
export interface CostBreakdown {
  projectId: string;
  projectName: string;
  cloud: CloudProvider;
  cost: number;
  percentage: number;
}

export interface CostSummary {
  thisMonth: number;
  lastMonth: number;
  budget: number;
  forecast: number;
  byProject: CostBreakdown[];
  byProvider: { provider: CloudProvider; cost: number; percentage: number }[];
}

// ─── API Response Types ────────────────────────────────────────
export interface ApiResponse<T> {
  data: T;
  message?: string;
  success: boolean;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// ─── Navigation Types ──────────────────────────────────────────
export interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  badge?: string | number;
  badgeVariant?: "default" | "blue" | "red" | "green";
}
