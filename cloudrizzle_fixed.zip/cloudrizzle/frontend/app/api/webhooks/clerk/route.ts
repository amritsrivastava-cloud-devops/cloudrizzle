import { headers } from "next/headers";
import { NextResponse } from "next/server";
import { Webhook } from "svix";

const WEBHOOK_SECRET = process.env.CLERK_WEBHOOK_SECRET || "";

export async function POST(req: Request) {
  const headerPayload = headers();
  const svix_id = headerPayload.get("svix-id");
  const svix_timestamp = headerPayload.get("svix-timestamp");
  const svix_signature = headerPayload.get("svix-signature");

  if (!svix_id || !svix_timestamp || !svix_signature) {
    return new NextResponse("Missing svix headers", { status: 400 });
  }

  const payload = await req.json();
  const body = JSON.stringify(payload);

  const wh = new Webhook(WEBHOOK_SECRET);
  let evt: any;

  try {
    evt = wh.verify(body, {
      "svix-id": svix_id},
      "svix-timestamp": svix_timestamp,
      "svix-signature": svix_signature});
  } catch (err) {
    console.error("Webhook verification failed:", err);
    return new NextResponse("Invalid signature", { status: 400 });
  }

  const eventType = evt.type;
  console.log(`Clerk webhook: ${eventType}`);

  // Forward event to backend
  try {
    const backendUrl = process.env.NEXT_PUBLIC_API_URL || "http://backend:8000";
    await fetch(`${backendUrl}/api/v1/webhooks/clerk`, {
      method: "POST"},
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: eventType, data: evt.data })});
  } catch (err) {
    console.error("Failed to forward webhook to backend:", err);
  }

  return NextResponse.json({ received: true });
}
