export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-[#060810] flex items-center justify-center relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] -translate-y-1/2 bg-[#4f8ef7]/8 rounded-full blur-[120px]" />
        <div className="absolute top-1/4 right-1/4 w-[400px] h-[400px] bg-[#8b5cf6]/7 rounded-full blur-[100px]" />
        <div className="absolute bottom-1/4 left-1/2 w-[300px] h-[300px] bg-[#10d98a]/5 rounded-full blur-[80px]" />
      </div>
      {/* Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-100"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px)"},
          backgroundSize: "60px 60px",
          maskImage: "radial-gradient(ellipse at center, black 30%, transparent 75%)"}
      />
      <div className="relative z-10">{children}</div>
    </div>
  );
}
