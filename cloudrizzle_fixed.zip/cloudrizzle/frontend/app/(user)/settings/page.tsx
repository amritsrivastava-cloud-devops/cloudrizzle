"use client";

import { useState } from "react";
import { Topbar } from "@/components/layout/Topbar";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Toggle } from "@/components/ui/Input";
import { SettingRow } from "@/components/ui/Alert";

export default function SettingsPage() {
  const [s, setS] = useState({
    autoValidate: true, showCost: true, autoApply: false},
    driftDetect: true, autoRemediate: false, stateBackup: true,
    deploySuccess: true, deployFail: true, costAlert: true, weeklyDigest: false});
  const tog = (k: keyof typeof s) => setS(prev => ({ ...prev, [k]: !prev[k] }));

  return (
    <>
      <Topbar title="Settings" crumb="workspace / settings" actions={<Button variant="primary" size="sm">Save Changes</Button>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Settings</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Manage your workspace preferences</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Card className="mb-4">
              <CardHeader title="AI Configuration" />
              <div className="px-5 py-1">
                <SettingRow label="Default AI Model" desc="claude-3.5-sonnet · most accurate">
                  <Button variant="ghost" size="sm" className="text-[10px] px-2.5">Change</Button>
                </SettingRow>
                <SettingRow label="Auto-validate Terraform" desc="Run policy checks before any apply">
                  <Toggle checked={s.autoValidate} onChange={() => tog("autoValidate")} />
                </SettingRow>
                <SettingRow label="Show cost estimate" desc="Display monthly cost before deploying">
                  <Toggle checked={s.showCost} onChange={() => tog("showCost")} />
                </SettingRow>
                <SettingRow label="Auto-apply approved plans" desc="Skip manual confirmation step">
                  <Toggle checked={s.autoApply} onChange={() => tog("autoApply")} />
                </SettingRow>
              </div>
            </Card>

            <Card>
              <CardHeader title="Infrastructure" />
              <div className="px-5 py-1">
                <SettingRow label="Drift detection" desc="Check infra every 6 hours">
                  <Toggle checked={s.driftDetect} onChange={() => tog("driftDetect")} />
                </SettingRow>
                <SettingRow label="Auto-remediate drift" desc="Automatically fix detected drift">
                  <Toggle checked={s.autoRemediate} onChange={() => tog("autoRemediate")} />
                </SettingRow>
                <SettingRow label="Terraform state backup" desc="Backup state to S3 daily">
                  <Toggle checked={s.stateBackup} onChange={() => tog("stateBackup")} />
                </SettingRow>
              </div>
            </Card>
          </div>

          <div>
            <Card className="mb-4">
              <CardHeader title="Notifications" />
              <div className="px-5 py-1">
                <SettingRow label="Deploy success" desc="Email on successful deploy">
                  <Toggle checked={s.deploySuccess} onChange={() => tog("deploySuccess")} />
                </SettingRow>
                <SettingRow label="Deploy failure" desc="Email + Slack on failure">
                  <Toggle checked={s.deployFail} onChange={() => tog("deployFail")} />
                </SettingRow>
                <SettingRow label="Cost alerts" desc="Alert at 80% of budget">
                  <Toggle checked={s.costAlert} onChange={() => tog("costAlert")} />
                </SettingRow>
                <SettingRow label="Weekly digest" desc="Summary every Monday">
                  <Toggle checked={s.weeklyDigest} onChange={() => tog("weeklyDigest")} />
                </SettingRow>
              </div>
            </Card>

            <Card>
              <CardHeader title="Danger Zone" />
              <div className="p-4 flex flex-col gap-2">
                <Button variant="danger" size="sm" className="justify-start text-xs py-2.5 px-3.5">
                  Delete all projects
                </Button>
                <Button variant="danger" size="sm" className="justify-start text-xs py-2.5 px-3.5">
                  Revoke all API keys
                </Button>
                <Button variant="danger" size="sm" className="justify-start text-xs py-2.5 px-3.5 bg-red-400/15">
                  Delete account permanently
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
