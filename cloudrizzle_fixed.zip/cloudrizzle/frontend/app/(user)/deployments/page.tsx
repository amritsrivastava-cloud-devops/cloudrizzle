import { Topbar } from "@/components/layout/Topbar";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Table, Tr, Td, TdMain } from "@/components/ui/Table";
import { CloudBadge, StatusPill } from "@/components/ui/Badge";
import { Alert } from "@/components/ui/Alert";
import { Filter } from "lucide-react";

const deployments = [
  { id: "#987688", project: "Production VPC Stack", cloud: "aws", version: "v1.2.0", env: "prod", duration: "—", by: "rahul@dev.com", time: "Dec 19, 04:37", status: "queued" },
  { id: "#876543", project: "Static Site + CDN", cloud: "aws", version: "+12 changes", env: "dev", duration: "1m 23s", by: "AI Generator", time: "Dec 17, 07:21", status: "success" },
  { id: "#765432", project: "aws deploy server", cloud: "aws", version: "v1.0.1", env: "prod", duration: "2m 08s", by: "rahul@dev.com", time: "Dec 12, 09:08", status: "success" },
  { id: "#654321", project: "Microservices AKS", cloud: "azure", version: "v1.0.0", env: "prod", duration: "8m 34s", by: "AI Generator", time: "Dec 11, 08:04", status: "failed" },
  { id: "#543210", project: "RDS PostgreSQL", cloud: "aws", version: "v2.1.0", env: "staging", duration: "3m 12s", by: "rahul@dev.com", time: "Dec 10, 14:22", status: "success" },
  { id: "#432109", project: "S3 Static Website", cloud: "aws", version: "v0.9.1", env: "prod", duration: "—", by: "rahul@dev.com", time: "Dec 09, 11:30", status: "pending" },
  { id: "#321098", project: "GCP Cloud Run", cloud: "gcp", version: "v3.0.0", env: "dev", duration: "45s", by: "AI Generator", time: "Dec 08, 09:15", status: "success" }];

export default function DeploymentsPage() {
  return (
    <>
      <Topbar
        title="Deployments"
        crumb="workspace / deployments"
        onSearch={() => {}
        actions={<Button variant="ghost" size="sm"><Filter size={11} /> Filter</Button>}
      />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Deployments</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Full deployment history across all projects</p>
        </div>

        <Alert variant="error" className="mb-4">
          1 deployment failed — Microservices AKS · Dec 11 · Azure AKS timeout.{" "}
          <span className="text-red-400 cursor-pointer underline">View error logs →</span>
        </Alert>

        <Card>
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/5">
            <span className="text-xs font-bold">All Deployments</span>
            <div className="flex gap-1.5">
              <Button variant="ghost" size="sm" className="text-[10px] py-1 px-2.5">All Status</Button>
              <Button variant="ghost" size="sm" className="text-[10px] py-1 px-2.5">All Clouds</Button>
            </div>
          </div>
          <Table headers={["ID", "Project", "Cloud", "Version", "Env", "Duration", "Triggered by", "Time", "Status"]}>
            {deployments.map((d) => (
              <Tr key={d.id}>
                <Td main>{d.id}</Td>
                <Td>{d.project}</Td>
                <Td><CloudBadge cloud={d.cloud} /></Td>
                <Td>{d.version}</Td>
                <Td>{d.env}</Td>
                <Td>{d.duration}</Td>
                <Td>{d.by}</Td>
                <Td>{d.time}</Td>
                <Td><StatusPill status={d.status} /></Td>
              </Tr>
            ))}
          </Table>
        </Card>
      </div>
    </>
  );
}
