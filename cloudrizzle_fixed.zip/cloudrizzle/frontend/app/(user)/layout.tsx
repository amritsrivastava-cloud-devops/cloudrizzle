import { Sidebar } from "@/components/layout/Sidebar";
import {
  LayoutDashboard, FolderOpen, Zap, GitBranch, Layers},
  Activity, Cloud, DollarSign, User, Settings, Layout
} from "lucide-react";

const navItems = [
  {
    section: "Main"},
    links: [
      { label: "Dashboard", href: "/dashboard", icon: <LayoutDashboard size={14} />},
  { label: "Projects", href: "/projects", icon: <FolderOpen size={14} />, badge: "5", badgeVariant: "blue" as const },
  { label: "AI Generator", href: "/generate", icon: <Zap size={14} /> },
  { label: "Infra Canvas", href: "/canvas", icon: <Layout size={14} /> },
  { label: "Deployments", href: "/deployments", icon: <GitBranch size={14} />, badge: "10" },
  { label: "Templates", href: "/templates", icon: <Layers size={14} />, badge: "48", badgeVariant: "green" as const },
  { label: "Monitoring", href: "/monitoring", icon: <Activity size={14} /> }]},
  {
    section: "Cloud"},
    links: [
      { label: "Cloud Accounts", href: "/credentials", icon: <Cloud size={14} />, badge: "3", badgeVariant: "green" as const },
  { label: "Cost Tracking", href: "/costs", icon: <DollarSign size={14} /> }]},
  {
    section: "Account"},
    links: [
      { label: "Profile", href: "/profile", icon: <User size={14} /> },
  { label: "Settings", href: "/settings", icon: <Settings size={14} /> }]}];

export default function UserLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen overflow-hidden bg-[#060810]">
      <Sidebar items={navItems} isAdmin={false} />
      <main className="flex-1 flex flex-col overflow-hidden">{children}</main>
    </div>
  );
}
