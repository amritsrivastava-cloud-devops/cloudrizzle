"use client";

import { Topbar } from "@/components/layout/Topbar";
import { StatCard, Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { StatusPill } from "@/components/ui/Badge";
import { DeployDot, Alert } from "@/components/ui/Alert";
import { AiPromptBox } from "@/components/dashboard/AiPromptBox";
import { useProjects } from "@/hooks/useProjects";
import { useDeployments } from "@/hooks/useDeployments";
import { useCostSummary } from "@/hooks/useCosts";
import { useRouter } from "next/navigation";
import { Plus } from "lucide-react";
import { timeAgo, formatCurrency } from "@/lib/utils";

function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`bg-[#151d32] rounded-lg animate-pulse ${className}`} />;
}

export default function DashboardPage() {
  const router = useRouter();
  const { data: projects, isLoading: projectsLoading } = useProjects();
  const { data: deployments, isLoading: deploysLoading } = useDeployments();
  const { data: costs, isLoading: costsLoading } = useCostSummary();

  const activeProjects = projects?.filter((p: any) => p.status === "active").length ?? 0;
  const failedDeploy = deployments?.find((d: any) => d.status === "failed");

  return (
    <>
      <Topbar
        title="Dashboard"
        crumb="workspace / overview"
        onSearch={() => {}
        actions={
          <Button variant="primary" size="sm" onClick={() => router.push("/projects")}>
            <Plus size={12} /> New Project
          </Button>
        }
      />
      <div className="flex-1 overflow-y-auto p-7 animate-fade-up">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Welcome back 👋</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">
            Your infrastructure at a glance · {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
          </p>
        </div>

        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="Active Projects" value={projectsLoading ? "—" : String(activeProjects)} desc={`${projects?.length ?? 0} total`} icon="📦" badge="+52%" badgeUp color="blue" />
          <StatCard label="Deployments" value={deploysLoading ? "—" : String(deployments?.length ?? 0)} desc="This month" icon="🚀" badge="+8%" badgeUp color="green" />
          <StatCard label="Monthly Cost" value={costsLoading ? "—" : formatCurrency(costs?.this_month ?? 0)} desc="Across all providers" icon="💰" badge="+3%" badgeDown color="amber" />
          <StatCard label="System Health" value="99%" desc="All systems operational" icon="✅" badge="stable" color="green" />
        </div>

        {failedDeploy && (
          <Alert variant="error" className="mb-4">
            Deployment failed · <span className="text-red-400 cursor-pointer underline" onClick={() => router.push("/deployments")}>View logs →</span>
          </Alert>
        )}

        <div className="grid grid-cols-[1fr_300px] gap-4">
          <div>
            <AiPromptBox />
            <Card>
              <CardHeader title="My Projects" action={<a href="/projects" className="text-[11px] text-[#4f8ef7] font-mono hover:opacity-70 cursor-pointer">view all →</a>} />
              {projectsLoading ? (
                <div className="p-4 flex flex-col gap-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
              ) : !projects?.length ? (
                <div className="py-10 text-center">
                  <div className="text-3xl opacity-20 mb-2">📦</div>
                  <div className="text-sm font-bold text-[#8493b8] mb-1">No projects yet</div>
                  <div className="text-[11px] font-mono text-[#4a567a] mb-3">Use AI Generator to create your first infra</div>
                  <Button variant="primary" size="sm" onClick={() => router.push("/generate")}>Generate Infrastructure</Button>
                </div>
              ) : (
                projects.slice(0, 5).map((p: any) => (
                  <div key={p.id} onClick={() => router.push("/projects")} className="flex items-center gap-3 px-5 py-3 border-b border-white/5 last:border-b-0 hover:bg-[#0f1525] cursor-pointer transition-colors">
                    <div className="w-[34px] h-[34px] rounded-[9px] flex items-center justify-center text-sm bg-blue-400/12 flex-shrink-0">⚡</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-[#e2e8f8] truncate">{p.name}</div>
                      <div className="text-[10px] font-mono text-[#4a567a] mt-0.5">{p.cloud.toUpperCase()} · {p.environment} · {p.last_deployed_at ? timeAgo(p.last_deployed_at) : "never deployed"}</div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <StatusPill status={p.status} />
                      <span className="text-[10px] font-mono text-[#8493b8]">{formatCurrency(p.monthly_cost)}/mo</span>
                    </div>
                  </div>
                ))
              )}
            </Card>
          </div>

          <Card className="h-fit">
            <CardHeader title="Recent Deployments" action={<a href="/deployments" className="text-[11px] text-[#4f8ef7] font-mono hover:opacity-70 cursor-pointer">view all →</a>} />
            {deploysLoading ? (
              <div className="p-4 flex flex-col gap-2">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
            ) : !deployments?.length ? (
              <div className="py-8 text-center"><div className="text-2xl opacity-20 mb-2">🚀</div><div className="text-xs font-mono text-[#4a567a]">No deployments yet</div></div>
            ) : (
              deployments.slice(0, 6).map((d: any) => (
                <div key={d.id} onClick={() => router.push("/deployments")} className="flex items-start gap-3 px-5 py-3 border-b border-white/5 last:border-b-0 hover:bg-[#0f1525] cursor-pointer transition-colors">
                  <DeployDot status={d.status} />
                  <div className="flex-1">
                    <div className="text-xs font-semibold text-[#e2e8f8]">{d.project_id}</div>
                    <div className="text-[10px] font-mono text-[#4a567a] mt-0.5 leading-relaxed">
                      {d.environment} · {d.version}<br />
                      <StatusPill status={d.status} /> · {timeAgo(d.created_at)}
                    </div>
                  </div>
                </div>
              ))
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
