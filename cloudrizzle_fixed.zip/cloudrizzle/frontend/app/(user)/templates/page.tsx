"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Topbar } from "@/components/layout/Topbar";
import { Button } from "@/components/ui/Button";
import { Tabs } from "@/components/ui/Alert";
import { useAppStore } from "@/store/appStore";

const TEMPLATES = [
  { id: "1", cloud: "aws" as const, tag: "AWS", tagColor: "text-amber-400 bg-amber-400/10", name: "3-Tier VPC Architecture", desc: "Production VPC with public/private subnets, NAT, ALB, EC2 auto-scaling, RDS Multi-AZ", resources: ["VPC", "EC2", "RDS", "ALB", "S3"], uses: 2841, rate: 98.4, popular: true, prompt: "Create production 3-tier AWS VPC with ALB, 2x EC2 t3.medium auto-scaling, RDS PostgreSQL Multi-AZ, S3 + CloudFront" },
  { id: "2", cloud: "aws" as const, tag: "AWS", tagColor: "text-amber-400 bg-amber-400/10", name: "Serverless API", desc: "Lambda + API Gateway + DynamoDB with CloudWatch logging and X-Ray tracing", resources: ["Lambda", "API GW", "DynamoDB", "CloudWatch"], uses: 1920, rate: 97.1, popular: false, prompt: "Create AWS serverless API with Lambda, API Gateway, DynamoDB, CloudWatch, X-Ray tracing" },
  { id: "3", cloud: "azure" as const, tag: "Azure", tagColor: "text-cyan-400 bg-cyan-400/10", name: "AKS Microservices", desc: "Azure Kubernetes cluster with ACR, Azure Monitor, Key Vault, Ingress controller", resources: ["AKS", "ACR", "Key Vault", "Monitor"], uses: 1247, rate: 91.2, popular: true, prompt: "Deploy AKS cluster 3 nodes Standard_D2s_v3, Azure Container Registry, Monitor, Key Vault, NGINX Ingress" },
  { id: "4", cloud: "gcp" as const, tag: "GCP", tagColor: "text-green-400 bg-green-400/10", name: "Cloud Run + SQL", desc: "Fully managed serverless app with Cloud Run, Cloud SQL PostgreSQL, VPC, Cloud Armor", resources: ["Cloud Run", "Cloud SQL", "Armor", "CDN"], uses: 892, rate: 96.8, popular: false, prompt: "Create GCP Cloud Run service 2vCPU 1GB, Cloud SQL PostgreSQL 14, VPC connector, Cloud Armor WAF" },
  { id: "5", cloud: "aws" as const, tag: "AWS", tagColor: "text-amber-400 bg-amber-400/10", name: "S3 Static Website", desc: "S3 + CloudFront CDN + Route53 + SSL via ACM with OAI access control", resources: ["S3", "CloudFront", "Route53", "ACM"], uses: 3102, rate: 99.8, popular: true, prompt: "Setup S3 static website with CloudFront CDN, Route53 DNS, ACM SSL certificate, OAI access control" },
  { id: "6", cloud: "multi" as const, tag: "Multi-cloud", tagColor: "text-violet-400 bg-violet-400/10", name: "Multi-Cloud DR", desc: "Active-passive DR — AWS primary + Azure backup, automated failover, health checks", resources: ["AWS VPC", "Azure VNet", "VPN", "DNS"], uses: 312, rate: 96.8, popular: false, isNew: true, prompt: "Setup multi-cloud DR with AWS primary VPC+EC2+RDS and Azure secondary, Route53 health check failover, site-to-site VPN" },
  { id: "7", cloud: "aws" as const, tag: "AWS", tagColor: "text-amber-400 bg-amber-400/10", name: "EKS Cluster", desc: "Managed Kubernetes with managed node groups, IAM roles, VPC CNI, Cluster Autoscaler", resources: ["EKS", "ECR", "IAM", "ALB"], uses: 1560, rate: 94.7, popular: false, prompt: "Deploy EKS cluster managed node groups t3.medium, ECR, IAM roles, VPC CNI, Cluster Autoscaler, ALB Ingress" },
  { id: "8", cloud: "azure" as const, tag: "Azure", tagColor: "text-cyan-400 bg-cyan-400/10", name: "Azure App Service", desc: "App Service Plan + Web App + Azure SQL + Redis + Key Vault + Application Insights", resources: ["App Service", "SQL", "Redis", "Insights"], uses: 741, rate: 98.1, popular: false, prompt: "Create Azure App Service plan Standard S2, Web App, Azure SQL, Redis Cache, Key Vault, Application Insights" },
  { id: "9", cloud: "gcp" as const, tag: "GCP", tagColor: "text-green-400 bg-green-400/10", name: "GKE Autopilot", desc: "GKE Autopilot with Workload Identity, Binary Authorization, Cloud Logging", resources: ["GKE", "Artifact Reg.", "IAM", "Logging"], uses: 483, rate: 97.3, popular: false, prompt: "Deploy GKE Autopilot cluster with Workload Identity, Binary Authorization, Cloud Logging, Artifact Registry" }];

export default function TemplatesPage() {
  const [activeTab, setActiveTab] = useState("all");
  const { setPrompt } = useAppStore();
  const router = useRouter();

  const filtered = activeTab === "all" ? TEMPLATES : TEMPLATES.filter(t => t.cloud === activeTab || (activeTab === "multi" && t.cloud === "multi"));

  const handleUse = (t: typeof TEMPLATES[0]) => {
    setPrompt(t.prompt);
    router.push("/generate");
  };

  return (
    <>
      <Topbar title="Templates" crumb="workspace / templates" onSearch={() => {} actions={<Button variant="primary" size="sm">Browse by category</Button>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Infrastructure Templates</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">48 pre-built, production-ready Terraform templates</p>
        </div>

        <Tabs
          tabs={[{ label: "All (48)", value: "all" }, { label: "AWS (28)", value: "aws" }, { label: "Azure (12)", value: "azure" }, { label: "GCP (8)", value: "gcp" }]}
          active={activeTab}
          onChange={setActiveTab}
        />

        <div className="grid grid-cols-3 gap-3.5">
          {filtered.map((t) => (
            <div key={t.id} className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px] hover:border-white/14 hover:-translate-y-0.5 transition-all cursor-pointer relative overflow-hidden group">
              {(t.popular || t.isNew) && (
                <div className={`absolute top-3.5 right-3.5 text-[9px] font-mono font-bold px-2 py-0.5 rounded-[6px] ${t.isNew ? "bg-blue-400/10 text-blue-400" : "bg-amber-400/10 text-amber-400"}`}>
                  {t.isNew ? "🆕 New" : "⭐ Popular"}
                </div>
              )}
              <div className={`text-[9px] font-bold font-mono uppercase tracking-[0.06em] px-2 py-0.5 rounded-[6px] mb-3 inline-block ${t.tagColor}`}>{t.tag}</div>
              <div className="text-sm font-bold text-[#e2e8f8] mb-1.5 tracking-[-0.02em]">{t.name}</div>
              <div className="text-[11px] font-mono text-[#8493b8] leading-[1.55] mb-3.5">{t.desc}</div>
              <div className="flex gap-1.5 flex-wrap mb-3.5">
                {t.resources.map((r) => (
                  <span key={r} className="text-[9px] bg-[#151d32] text-[#8493b8] px-1.5 py-0.5 rounded-[5px] font-mono">{r}</span>
                ))}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-[#4a567a]">Used {t.uses.toLocaleString()} times</span>
                <button
                  onClick={() => handleUse(t)}
                  className="px-3 py-1.5 bg-[#4f8ef7]/10 text-[#4f8ef7] border border-[#4f8ef7]/20 rounded-[7px] text-[11px] font-bold hover:bg-[#4f8ef7] hover:text-white transition-all"
                >
                  Use Template
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
