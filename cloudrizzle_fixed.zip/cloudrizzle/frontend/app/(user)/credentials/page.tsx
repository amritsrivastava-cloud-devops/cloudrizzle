// credentials/page.tsx
export { default } from "./CredentialsPage";
