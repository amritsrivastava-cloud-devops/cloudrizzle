import { Topbar } from "@/components/layout/Topbar";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Table, Tr, Td, TdMain } from "@/components/ui/Table";
import { CloudBadge, StatusPill } from "@/components/ui/Badge";
import { Plus, Filter } from "lucide-react";

const projects = [
  { id: "1", name: "Production VPC Stack", desc: "EC2 + RDS + ALB + Route53", cloud: "aws", resources: 8, env: "production", cost: 340, lastDeploy: "2h ago", status: "active" },
  { id: "2", name: "aws deploy server ec2", desc: "EC2 t3.medium + Security Groups", cloud: "aws", resources: 3, env: "production", cost: 62, lastDeploy: "5h ago", status: "active" },
  { id: "3", name: "S3 Static Website", desc: "S3 + CloudFront + ACM Certificate", cloud: "aws", resources: 4, env: "production", cost: 8, lastDeploy: "1d ago", status: "queued" },
  { id: "4", name: "Microservices AKS", desc: "Azure Kubernetes Service + ACR", cloud: "azure", resources: 12, env: "staging", cost: 890, lastDeploy: "2d ago", status: "error" },
  { id: "5", name: "GCP Cloud Run API", desc: "Cloud Run + Cloud SQL + Armor", cloud: "gcp", resources: 5, env: "development", cost: 112, lastDeploy: "3d ago", status: "active" }];

export default function ProjectsPage() {
  return (
    <>
      <Topbar
        title="Projects"
        crumb="workspace / projects"
        onSearch={() => {}
        actions={
          <>
            <Button variant="ghost" size="sm"><Filter size={11} /> Filter</Button>
            <Button variant="primary" size="sm"><Plus size={12} /> New Project</Button>
          </>
        }
      />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-[22px] font-black tracking-[-0.04em]">My Projects</h1>
            <p className="text-xs font-mono text-[#8493b8] mt-1">5 projects · 3 cloud providers</p>
          </div>
        </div>

        <Card>
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/5">
            <span className="text-xs font-bold">All Projects</span>
            <div className="flex gap-1.5">
              <Button variant="ghost" size="sm" className="text-[10px] py-1 px-2.5">Sort</Button>
              <Button variant="ghost" size="sm" className="text-[10px] py-1 px-2.5">Filter</Button>
            </div>
          </div>
          <Table headers={["Project", "Cloud", "Resources", "Environment", "Monthly Cost", "Last Deploy", "Status", ""]}>
            {projects.map((p) => (
              <Tr key={p.id}>
                <TdMain main={p.name} sub={p.desc} />
                <Td><CloudBadge cloud={p.cloud} /></Td>
                <Td>{p.resources}</Td>
                <Td>{p.env}</Td>
                <Td className={p.cost > 500 ? "text-red-400" : p.cost > 200 ? "text-amber-400" : ""}>
                  ${p.cost.toLocaleString()}.00
                </Td>
                <Td>{p.lastDeploy}</Td>
                <Td><StatusPill status={p.status} /></Td>
                <Td>
                  <Button variant="ghost" size="sm" className="text-[10px] py-1 px-2">View</Button>
                </Td>
              </Tr>
            ))}
          </Table>
        </Card>
      </div>
    </>
  );
}
