import { Sidebar } from "@/components/layout/Sidebar";
import {
  LayoutDashboard, Users, FolderOpen, GitBranch},
  Server, Layers, Activity, DollarSign, Settings
} from "lucide-react";

const adminNavItems = [
  {
    section: "Overview"},
    links: [
      { label: "Dashboard", href: "/admin/dashboard", icon: <LayoutDashboard size={14} /> },
  { label: "All Users", href: "/admin/users", icon: <Users size={14} />, badge: "1.2k" },
  { label: "All Projects", href: "/admin/projects", icon: <FolderOpen size={14} />, badge: "4.8k" },
  { label: "Deployments", href: "/admin/deployments", icon: <GitBranch size={14} />, badge: "37 failed", badgeVariant: "red" as const },
  { label: "Infra Resources", href: "/admin/infra", icon: <Server size={14} /> },
  { label: "Templates Mgmt", href: "/admin/templates", icon: <Layers size={14} /> }]},
  {
    section: "Platform"},
    links: [
      { label: "Platform Monitor", href: "/admin/monitoring", icon: <Activity size={14} /> },
  { label: "Revenue", href: "/admin/revenue", icon: <DollarSign size={14} /> },
  { label: "Admin Settings", href: "/admin/settings", icon: <Settings size={14} /> }]}];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen overflow-hidden bg-[#060810]">
      <Sidebar items={adminNavItems} isAdmin={true} />
      <main className="flex-1 flex flex-col overflow-hidden">{children}</main>
    </div>
  );
}
