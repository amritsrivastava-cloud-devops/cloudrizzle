"use client";

import { useState } from "react";
import { Topbar } from "@/components/layout/Topbar";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Toggle } from "@/components/ui/Input";
import { SettingRow } from "@/components/ui/Alert";

export default function AdminSettingsPage() {
  const [s, setS] = useState({
    maintenance: false, signups: true, freeTier: true},
    autoSuspend: true, driftDetect: true,
    force2fa: true, ipAllowlist: false, auditLog: true});
  const tog = (k: keyof typeof s) => setS(prev => ({ ...prev, [k]: !prev[k] }));

  return (
    <>
      <Topbar title="Admin Settings" crumb="admin / settings" actions={<Button variant="admin" size="sm">Save Changes</Button>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Admin Settings</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Platform-wide configuration and controls</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Card className="mb-4">
              <CardHeader title="Platform Config" />
              <div className="px-5 py-1">
                <SettingRow label="Maintenance mode" desc="Block all user logins">
                  <Toggle checked={s.maintenance} onChange={() => tog("maintenance")} admin />
                </SettingRow>
                <SettingRow label="New user signups" desc="Allow new registrations">
                  <Toggle checked={s.signups} onChange={() => tog("signups")} admin />
                </SettingRow>
                <SettingRow label="Free tier" desc="Allow free plan (2 projects max)">
                  <Toggle checked={s.freeTier} onChange={() => tog("freeTier")} admin />
                </SettingRow>
                <SettingRow label="Auto-suspend on payment fail" desc="After 3 failed payment attempts">
                  <Toggle checked={s.autoSuspend} onChange={() => tog("autoSuspend")} admin />
                </SettingRow>
                <SettingRow label="Global drift detection" desc="Run checks across all users every 6h">
                  <Toggle checked={s.driftDetect} onChange={() => tog("driftDetect")} admin />
                </SettingRow>
              </div>
            </Card>

            <Card>
              <CardHeader title="AI Configuration" />
              <div className="px-5 py-1">
                <SettingRow label="Default AI model" desc="claude-3.5-sonnet for all users">
                  <Button variant="ghost" size="sm" className="text-[10px] px-2.5">Change</Button>
                </SettingRow>
                <SettingRow label="Free tier AI credits" desc="50 credits per month">
                  <Button variant="ghost" size="sm" className="text-[10px] px-2.5">Edit</Button>
                </SettingRow>
                <SettingRow label="Pro tier AI credits" desc="1,000 credits per month">
                  <Button variant="ghost" size="sm" className="text-[10px] px-2.5">Edit</Button>
                </SettingRow>
              </div>
            </Card>
          </div>

          <div>
            <Card className="mb-4">
              <CardHeader title="Security" />
              <div className="px-5 py-1">
                <SettingRow label="Force 2FA for enterprise" desc="Mandatory 2FA on enterprise plan">
                  <Toggle checked={s.force2fa} onChange={() => tog("force2fa")} admin />
                </SettingRow>
                <SettingRow label="IP allowlist enforcement" desc="Block requests from unallowed IPs">
                  <Toggle checked={s.ipAllowlist} onChange={() => tog("ipAllowlist")} admin />
                </SettingRow>
                <SettingRow label="Audit logging" desc="Log all admin actions">
                  <Toggle checked={s.auditLog} onChange={() => tog("auditLog")} admin />
                </SettingRow>
              </div>
            </Card>

            <Card>
              <CardHeader title="Danger Zone" />
              <div className="p-4 flex flex-col gap-2">
                <Button variant="danger" size="sm" className="justify-start text-xs py-2.5 px-3.5">
                  Purge all cached data
                </Button>
                <Button variant="danger" size="sm" className="justify-start text-xs py-2.5 px-3.5">
                  Reset all Terraform states
                </Button>
                <Button variant="danger" size="sm" className="justify-start text-xs py-2.5 px-3.5 bg-red-400/15">
                  Emergency: kill all deployments
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
