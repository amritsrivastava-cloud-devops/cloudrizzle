import { Topbar } from "@/components/layout/Topbar";
import { StatCard, Card } from "@/components/ui/Card";
import { Table, Tr, Td, TdMain } from "@/components/ui/Table";
import { CloudBadge, StatusPill } from "@/components/ui/Badge";

const resources = [
  { id: "i-0a1b2c3d4e5f", type: "EC2 Instance", owner: "Rahul Dev", project: "VPC Stack", cloud: "aws", region: "us-east-1", cost: 30.24, status: "running" },
  { id: "db-0f1e2d3c4b", type: "RDS PostgreSQL", owner: "Rahul Dev", project: "VPC Stack", cloud: "aws", region: "us-east-1", cost: 82.00, status: "available" },
  { id: "aks-cluster-prod", type: "AKS Cluster", owner: "Sneha Patel", project: "Microservices", cloud: "azure", region: "eastus", cost: 420.00, status: "degraded" },
  { id: "bq-dataset-main", type: "BigQuery Dataset", owner: "Arjun Mehta", project: "Data Platform", cloud: "gcp", region: "us-central1", cost: 1200.00, status: "active" },
  { id: "elb-0a9b8c7d6e", type: "Elastic LB", owner: "Vikram Singh", project: "Multi-Region LB", cloud: "aws", region: "us-west-2", cost: 18.40, status: "active" },
  { id: "run-api-prod-v3", type: "Cloud Run Service", owner: "Kavita Nair", project: "GCP Cloud Run", cloud: "gcp", region: "us-central1", cost: 45.20, status: "running" }];

export default function AdminInfraPage() {
  return (
    <>
      <Topbar title="Infra Resources" crumb="admin / infra-resources" />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Infra Resources</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">All cloud resources across all users — 12,840 total</p>
        </div>

        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="Total Resources" value="12,840" color="blue" />
          <StatCard label="AWS Resources" value="8,731" color="amber" />
          <StatCard label="Azure Resources" value="2,824" color="cyan" />
          <StatCard label="GCP Resources" value="1,285" color="green" />
        </div>

        <Card>
          <Table headers={["Resource ID", "Type", "Owner", "Project", "Cloud", "Region", "Monthly Cost", "State"]}>
            {resources.map((r) => (
              <Tr key={r.id}>
                <Td main>{r.id}</Td>
                <Td>{r.type}</Td>
                <Td>{r.owner}</Td>
                <Td>{r.project}</Td>
                <Td><CloudBadge cloud={r.cloud} /></Td>
                <Td>{r.region}</Td>
                <Td className={r.cost > 500 ? "text-amber-400" : ""}>${r.cost.toFixed(2)}</Td>
                <Td><StatusPill status={r.status} /></Td>
              </Tr>
            ))}
          </Table>
        </Card>
      </div>
    </>
  );
}
