import { Topbar } from "@/components/layout/Topbar";
import { StatCard, Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Table, Tr, Td, TdMain, TdUser } from "@/components/ui/Table";
import { CloudBadge, StatusPill, PlanBadge } from "@/components/ui/Badge";
import { Alert, Avatar, MiniBar } from "@/components/ui/Alert";

const users = [
  { name: "Rahul Dev", email: "rahul@dev.com", av: "R", avV: "blue", plan: "pro", projects: 5, spend: 1412, status: "active" },
  { name: "Priya Sharma", email: "priya@startup.io", av: "P", avV: "green", plan: "free", projects: 2, spend: 0, status: "active" },
  { name: "Arjun Mehta", email: "arjun@techcorp.in", av: "A", avV: "amber", plan: "enterprise", projects: 18, spend: 8240, status: "active" },
  { name: "Sneha Patel", email: "sneha@cloud.dev", av: "S", avV: "violet", plan: "pro", projects: 7, spend: 3108, status: "suspended" },
  { name: "Vikram Singh", email: "vikram@infra.co", av: "V", avV: "red", plan: "enterprise", projects: 31, spend: 14520, status: "active" }];

export default function AdminDashboardPage() {
  return (
    <>
      <Topbar title="Admin Dashboard" crumb="admin / overview" onSearch={() => {} actions={<Button variant="admin" size="sm">Export Report</Button>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Platform Overview</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Full visibility — all users, projects, deployments, revenue</p>
        </div>

        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="Total Users" value="1,284" desc="124 new this month" icon="👥" badge="+18%" badgeUp color="orange" />
          <StatCard label="Total Projects" value="4,821" desc="Across 3 clouds" icon="📦" badge="+23%" badgeUp color="blue" />
          <StatCard label="Monthly Revenue" value="$28.4k" desc="MRR · up from $25.6k" icon="💵" badge="+11%" badgeUp color="green" />
          <StatCard label="Failed Deploys" value="37" desc="Last 30 days" icon="⚠️" badge="needs fix" badgeDown color="red" />
        </div>

        <Alert variant="error" className="mb-4">
          37 deployment failures in last 30 days — 12 Azure AKS timeouts, 8 Terraform state lock errors. Review recommended.
        </Alert>

        <div className="grid grid-cols-[1fr_280px] gap-4">
          <Card>
            <CardHeader title="Recent Users" action={<a href="/admin/users" className="text-[11px] text-[#f97316] font-mono hover:opacity-70">view all 1,284 →</a>} />
            <Table headers={["User", "Plan", "Projects", "Cloud Spend", "Status"]}>
              {users.map((u) => (
                <Tr key={u.email}>
                  <TdUser name={u.name} sub={u.email} avatar={<Avatar name={u.av} variant={u.avV} className="w-[26px] h-[26px]" />} />
                  <Td><PlanBadge plan={u.plan} /></Td>
                  <Td>{u.projects}</Td>
                  <Td className={u.spend > 5000 ? "text-red-400" : u.spend > 1000 ? "text-amber-400" : ""}>${u.spend.toLocaleString()}</Td>
                  <Td><StatusPill status={u.status} /></Td>
                </Tr>
              ))}
            </Table>
          </Card>

          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em] mb-3.5">Cloud Distribution</div>
            <MiniBar label="AWS" value={68} color="#f59e0b" />
            <MiniBar label="Azure" value={22} color="#06b6d4" />
            <MiniBar label="GCP" value={10} color="#10d98a" />
            <div className="border-t border-white/5 mt-4 pt-4">
              <div className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em] mb-3">Plan Distribution</div>
              <MiniBar label="Enterprise" value={18} color="#8b5cf6" />
              <MiniBar label="Pro" value={45} color="#4f8ef7" />
              <MiniBar label="Free" value={37} color="#1c2640" />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
