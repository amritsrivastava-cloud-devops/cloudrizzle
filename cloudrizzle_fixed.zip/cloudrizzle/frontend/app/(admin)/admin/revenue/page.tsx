import { Topbar } from "@/components/layout/Topbar";
import { StatCard } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { MiniBar } from "@/components/ui/Alert";

const mrrSpark = [40, 50, 55, 60, 65, 70, 75, 80, 88, 95, 100];
const topUsers = [
  { name: "Vikram S.", value: 90, color: "#8b5cf6", amount: "$290" },
  { name: "Arjun M.", value: 72, color: "#f59e0b", amount: "$232" },
  { name: "Sneha P.", value: 55, color: "#4f8ef7", amount: "$180" },
  { name: "Rahul D.", value: 28, color: "#4f8ef7", amount: "$29" },
  { name: "Kavita N.", value: 28, color: "#4f8ef7", amount: "$29" }];

export default function AdminRevenuePage() {
  return (
    <>
      <Topbar title="Revenue" crumb="admin / revenue" actions={<Button variant="ghost" size="sm">Export</Button>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Revenue</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Platform MRR, subscriptions and billing</p>
        </div>

        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="MRR" value="$28.4k" desc="Monthly Recurring Revenue" icon="💵" badge="+11%" badgeUp color="green" />
          <StatCard label="ARR" value="$340k" desc="Annual run rate" icon="📈" badge="+18%" badgeUp color="blue" />
          <StatCard label="Churn Rate" value="4.2%" desc="Monthly churn" icon="🔄" badge="4.2%" color="amber" />
          <StatCard label="ARPU" value="$22.10" desc="Avg revenue per user" icon="⬆️" badge="+6%" badgeUp color="violet" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* MRR Growth */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">MRR Growth</span>
              <span className="text-[11px] font-semibold text-green-400">+11% MoM</span>
            </div>
            <div className="flex items-end gap-0.5 h-14 mb-4">
              {mrrSpark.map((v, i) => (
                <div key={i} className="flex-1 rounded-t-sm" style={{ height: `${v}%`, background: "#10d98a", opacity: 0.4 + v / 200 } />
              ))}
            </div>
            <div className="flex gap-5">
              {[["Enterprise", "$18.2k", "text-violet-400"], ["Pro", "$10.2k", "text-blue-400"], ["Free", "$0", "text-[#8493b8]"]].map(([k, v, c]) => (
                <div key={k as string}>
                  <div className="text-[9px] font-mono text-[#4a567a]">{k}</div>
                  <div className={`text-base font-bold mt-0.5 ${c}`}>{v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Top Users */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="mb-4">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">Top Paying Users</span>
            </div>
            {topUsers.map((u) => (
              <div key={u.name} className="flex items-center gap-2 mb-2">
                <div className="text-[10px] font-mono text-[#8493b8] w-[72px] flex-shrink-0">{u.name}</div>
                <div className="flex-1 h-1.5 bg-[#1c2640] rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${u.value}%`, background: u.color } />
                </div>
                <div className="text-[10px] font-mono text-[#8493b8] w-10 text-right" style={{ color: u.color }>{u.amount}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
