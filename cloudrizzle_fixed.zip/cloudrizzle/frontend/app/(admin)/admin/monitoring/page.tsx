import { Topbar } from "@/components/layout/Topbar";
import { StatCard } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { MiniBar } from "@/components/ui/Alert";

const reqSpark = [45, 52, 60, 48, 70, 85, 78, 65, 72, 80, 100];
const uptimeData = Array.from({ length: 90 }, (_, i) => (i === 5 || i === 54) ? "warn" : i === 25 ? "error" : "ok");
const dotClass: Record<string, string> = { ok: "bg-green-400/90", warn: "bg-amber-400", error: "bg-red-400" };

const logs = [
  { ts: "14:32:01", lvl: "INFO", msg: "Temporal workflow deploy#987688 started" },
  { ts: "14:31:58", lvl: "INFO", msg: "User rahul@dev.com authenticated via Clerk" },
  { ts: "14:31:44", lvl: "WARN", msg: "PostgreSQL pool 48/100 connections used" },
  { ts: "14:31:32", lvl: "ERROR", msg: "Azure AKS deploy#654321 timeout after 8m34s" },
  { ts: "14:30:17", lvl: "INFO", msg: "AI Generator: Terraform validated OK" },
  { ts: "14:29:55", lvl: "INFO", msg: "Redis cache hit rate: 94.2%" }];
const lvlColor: Record<string, string> = { INFO: "text-blue-400", WARN: "text-amber-400", ERROR: "text-red-400" };

export default function AdminMonitoringPage() {
  return (
    <>
      <Topbar title="Platform Monitoring" crumb="admin / monitoring" actions={<><Button variant="ghost" size="sm">Last 24h</Button><Button variant="ghost" size="sm">Open Grafana →</Button></>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Platform Monitoring</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Prometheus · Grafana · Loki · OpenTelemetry</p>
        </div>

        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="Platform Uptime" value="99.2%" desc="Last 90 days" icon="✅" badge="live" color="green" />
          <StatCard label="API Latency" value="142ms" desc="p95 avg response" icon="⚡" badge="fast" badgeUp color="blue" />
          <StatCard label="Active Connections" value="284" desc="Current live sessions" icon="🔌" badge="normal" color="amber" />
          <StatCard label="Queue Depth" value="47" desc="Pending Temporal jobs" icon="📋" badge="stable" color="violet" />
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          {/* Server Resources */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-4">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">Server Resources</span>
              <span className="text-[11px] font-semibold text-amber-400">Memory High</span>
            </div>
            <MiniBar label="CPU" value={34} color="#4f8ef7" />
            <MiniBar label="Memory" value={58} color="#f59e0b" />
            <MiniBar label="Disk" value={41} color="#4f8ef7" />
            <MiniBar label="Network" value={22} color="#10d98a" />
            <div className="border-t border-white/5 mt-3 pt-3 flex flex-col gap-1.5">
              {[["Docker containers", "6/6 healthy", "text-green-400"], ["PostgreSQL conns", "48/100", "text-[#8493b8]"], ["Redis memory", "1.2GB / 4GB", "text-[#8493b8]"]].map(([k, v, c]) => (
                <div key={k as string} className="flex justify-between">
                  <span className="text-[10px] font-mono text-[#4a567a]">{k}</span>
                  <span className={`text-[10px] font-mono ${c}`}>{v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Request Volume */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">Request Volume</span>
              <span className="text-[11px] font-semibold text-[#4f8ef7]">2,841 req/min</span>
            </div>
            <div className="flex items-end gap-0.5 h-12 mb-3">
              {reqSpark.map((v, i) => (
                <div key={i} className="flex-1 rounded-t-sm min-w-[6px]" style={{ height: `${v}%`, background: "#4f8ef7", opacity: 0.4 + v / 200 } />
              ))}
            </div>
            <div className="flex gap-5">
              {[["Peak today", "4,200/min", "text-[#e2e8f8]"], ["Error rate", "0.3%", "text-amber-400"], ["p99 latency", "320ms", "text-green-400"]].map(([k, v, c]) => (
                <div key={k as string}>
                  <div className="text-[9px] font-mono text-[#4a567a]">{k}</div>
                  <div className={`text-sm font-bold mt-0.5 ${c}`}>{v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Uptime */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">Platform Uptime — 90 days</span>
            </div>
            <div className="flex gap-0.5 flex-wrap">
              {uptimeData.map((s, i) => (
                <div key={i} className={`w-2.5 h-2.5 rounded-[3px] ${dotClass[s]}`} />
              ))}
            </div>
          </div>

          {/* Logs */}
          <div className="bg-[#0a0e1a] border border-white/5 rounded-[14px] p-[18px]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-bold text-[#8493b8] uppercase tracking-[0.05em]">Platform Logs</span>
              <span className="text-[11px] font-semibold text-green-400">Loki · Live</span>
            </div>
            <div className="bg-[#0f1525] rounded-[8px] p-2.5 max-h-[180px] overflow-y-auto">
              {logs.map((l, i) => (
                <div key={i} className="flex gap-2.5 py-1.5 border-b border-white/5 last:border-b-0 text-[10px] font-mono">
                  <span className="text-[#4a567a] flex-shrink-0 w-[72px]">{l.ts}</span>
                  <span className={`flex-shrink-0 w-10 ${lvlColor[l.lvl]}`}>{l.lvl}</span>
                  <span className="text-[#8493b8]">{l.msg}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
