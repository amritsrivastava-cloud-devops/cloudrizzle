import { Topbar } from "@/components/layout/Topbar";
import { StatCard, Card } from "@/components/ui/Card";
import { Table, Tr, Td, TdMain } from "@/components/ui/Table";
import { CloudBadge, StatusPill } from "@/components/ui/Badge";
import { Alert } from "@/components/ui/Alert";

const deployments = [
  { id: "#987688", user: "Rahul Dev", project: "Production VPC", cloud: "aws", version: "v1.2.0", env: "prod", duration: "—", time: "Dec 19, 04:37", status: "queued" },
  { id: "#876543", user: "Arjun Mehta", project: "Enterprise Data Plt.", cloud: "gcp", version: "+12", env: "prod", duration: "1m 23s", time: "Dec 17, 07:21", status: "success" },
  { id: "#765432", user: "Vikram Singh", project: "Multi-Region LB", cloud: "aws", version: "v1.0.1", env: "prod", duration: "2m 08s", time: "Dec 12, 09:08", status: "success" },
  { id: "#654321", user: "Sneha Patel", project: "Microservices AKS", cloud: "azure", version: "v1.0.0", env: "prod", duration: "8m 34s", time: "Dec 11, 08:04", status: "failed" },
  { id: "#543210", user: "Kavita Nair", project: "GCP Cloud Run", cloud: "gcp", version: "v2.1.0", env: "dev", duration: "45s", time: "Dec 10, 14:22", status: "success" },
  { id: "#432109", user: "Priya Sharma", project: "S3 Static Site", cloud: "aws", version: "v0.9.1", env: "prod", duration: "—", time: "Dec 09, 11:30", status: "pending" }];

export default function AdminDeploymentsPage() {
  return (
    <>
      <Topbar title="All Deployments" crumb="admin / deployments" />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">All Deployments</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Platform-wide deployment activity</p>
        </div>

        <Alert variant="error" className="mb-5">
          37 failures detected — 12 Azure AKS timeouts, 8 Terraform state locks, 17 other.{" "}
          <span className="text-red-400 cursor-pointer underline">View failure analysis →</span>
        </Alert>

        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="Total (30d)" value="1,284" color="blue" />
          <StatCard label="Success" value="1,247" color="green" />
          <StatCard label="Failed" value="37" color="red" />
          <StatCard label="Success Rate" value="97.1%" color="amber" />
        </div>

        <Card>
          <Table headers={["Deploy ID", "User", "Project", "Cloud", "Version", "Env", "Duration", "Time", "Status"]}>
            {deployments.map((d) => (
              <Tr key={d.id}>
                <Td main>{d.id}</Td>
                <Td>{d.user}</Td>
                <Td>{d.project}</Td>
                <Td><CloudBadge cloud={d.cloud} /></Td>
                <Td>{d.version}</Td>
                <Td>{d.env}</Td>
                <Td>{d.duration}</Td>
                <Td>{d.time}</Td>
                <Td><StatusPill status={d.status} /></Td>
              </Tr>
            ))}
          </Table>
        </Card>
      </div>
    </>
  );
}
