import { Topbar } from "@/components/layout/Topbar";
import { StatCard, Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Table, Tr, Td, TdUser } from "@/components/ui/Table";
import { CloudBadge, StatusPill, PlanBadge } from "@/components/ui/Badge";
import { Avatar } from "@/components/ui/Alert";
import { Filter } from "lucide-react";

const users = [
  { name: "Rahul Dev", email: "rahul@dev.com", av: "R", avV: "blue", plan: "pro", projects: 5, deploys: 10, cloud: "aws", spend: 1412, joined: "Jan 2025", last: "2h ago", status: "active" },
  { name: "Priya Sharma", email: "priya@startup.io", av: "P", avV: "green", plan: "free", projects: 2, deploys: 3, cloud: "azure", spend: 0, joined: "Feb 2025", last: "1d ago", status: "active" },
  { name: "Arjun Mehta", email: "arjun@techcorp.in", av: "A", avV: "amber", plan: "enterprise", projects: 18, deploys: 47, cloud: "gcp", spend: 8240, joined: "Nov 2024", last: "30m ago", status: "active" },
  { name: "Sneha Patel", email: "sneha@cloud.dev", av: "S", avV: "violet", plan: "pro", projects: 7, deploys: 12, cloud: "aws", spend: 3108, joined: "Dec 2024", last: "3d ago", status: "suspended" },
  { name: "Vikram Singh", email: "vikram@infra.co", av: "V", avV: "red", plan: "enterprise", projects: 31, deploys: 89, cloud: "aws", spend: 14520, joined: "Sep 2024", last: "5h ago", status: "active" },
  { name: "Kavita Nair", email: "kavita@cloud9.io", av: "K", avV: "cyan", plan: "pro", projects: 4, deploys: 8, cloud: "gcp", spend: 740, joined: "Mar 2025", last: "1h ago", status: "active" }];

export default function AdminUsersPage() {
  return (
    <>
      <Topbar title="All Users" crumb="admin / users" onSearch={() => {} actions={<><Button variant="ghost" size="sm"><Filter size={11} />Filter</Button><Button variant="ghost" size="sm">Export CSV</Button><Button variant="admin" size="sm">Invite User</Button></>} />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">All Users</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">1,284 registered · 124 new this month · 37% free tier</p>
        </div>

        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="Total Users" value="1,284" color="blue" />
          <StatCard label="Active Today" value="284" color="green" />
          <StatCard label="Suspended" value="12" color="amber" />
          <StatCard label="Enterprise" value="231" color="violet" />
        </div>

        <Card>
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/5">
            <span className="text-xs font-bold">Users</span>
            <div className="flex gap-1.5">
              <Button variant="ghost" size="sm" className="text-[10px] py-1 px-2.5">All Plans</Button>
              <Button variant="ghost" size="sm" className="text-[10px] py-1 px-2.5">All Status</Button>
            </div>
          </div>
          <Table headers={["User", "Plan", "Projects", "Deploys", "Cloud", "Monthly Spend", "Joined", "Last Active", "Status", ""]}>
            {users.map((u) => (
              <Tr key={u.email}>
                <TdUser name={u.name} sub={u.email} avatar={<Avatar name={u.av} variant={u.avV} className="w-[26px] h-[26px]" />} />
                <Td><PlanBadge plan={u.plan} /></Td>
                <Td>{u.projects}</Td>
                <Td>{u.deploys}</Td>
                <Td><CloudBadge cloud={u.cloud} /></Td>
                <Td className={u.spend > 5000 ? "text-red-400" : u.spend > 1000 ? "text-amber-400" : ""}>${u.spend.toLocaleString()}</Td>
                <Td>{u.joined}</Td>
                <Td>{u.last}</Td>
                <Td><StatusPill status={u.status} /></Td>
                <Td><Button variant="ghost" size="sm" className="text-[10px] py-1 px-2">View</Button></Td>
              </Tr>
            ))}
          </Table>
        </Card>
      </div>
    </>
  );
}
