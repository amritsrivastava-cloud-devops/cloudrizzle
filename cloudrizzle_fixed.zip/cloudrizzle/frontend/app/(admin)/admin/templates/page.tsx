import { Topbar } from "@/components/layout/Topbar";
import { StatCard, Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Table, Tr, Td, TdMain } from "@/components/ui/Table";
import { CloudBadge, StatusPill } from "@/components/ui/Badge";
import { Plus } from "lucide-react";

const templates = [
  { name: "S3 Static Website", cloud: "aws", category: "Static hosting", resources: "S3, CloudFront, ACM", uses: 3102, rate: 99.8, updated: "Mar 2025", status: "published" },
  { name: "3-Tier VPC", cloud: "aws", category: "Networking", resources: "VPC, EC2, RDS, ALB", uses: 2841, rate: 98.4, updated: "Apr 2025", status: "published" },
  { name: "Serverless API", cloud: "aws", category: "Serverless", resources: "Lambda, API GW, DDB", uses: 1920, rate: 97.1, updated: "Feb 2025", status: "published" },
  { name: "AKS Microservices", cloud: "azure", category: "Kubernetes", resources: "AKS, ACR, Key Vault", uses: 1247, rate: 91.2, updated: "Jan 2025", status: "published" },
  { name: "Multi-Cloud DR", cloud: "aws", category: "Disaster Recovery", resources: "VPC, VNet, VPN, DNS", uses: 312, rate: 96.8, updated: "Apr 2025", status: "published" },
  { name: "GKE Autopilot", cloud: "gcp", category: "Kubernetes", resources: "GKE, Artifact Reg.", uses: 483, rate: 97.3, updated: "Mar 2025", status: "published" }];

export default function AdminTemplatesPage() {
  return (
    <>
      <Topbar
        title="Templates Management"
        crumb="admin / templates"
        onSearch={() => {}
        actions={<><Button variant="ghost" size="sm">Export</Button><Button variant="admin" size="sm"><Plus size={12} /> New Template</Button></>}
      />
      <div className="flex-1 overflow-y-auto p-7">
        <div className="mb-6">
          <h1 className="text-[22px] font-black tracking-[-0.04em]">Templates Management</h1>
          <p className="text-xs font-mono text-[#8493b8] mt-1">Manage the 48 pre-built infrastructure templates</p>
        </div>

        <div className="grid grid-cols-4 gap-3.5 mb-5">
          <StatCard label="Total Templates" value="48" color="blue" />
          <StatCard label="Total Uses" value="18.4k" color="green" />
          <StatCard label="Most Popular" value="S3 Site" color="amber" />
          <StatCard label="New This Month" value="3" color="violet" />
        </div>

        <Card>
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/5">
            <span className="text-xs font-bold">All Templates</span>
          </div>
          <Table headers={["Template", "Cloud", "Category", "Resources", "Uses (30d)", "Success Rate", "Last Updated", "Status", ""]}>
            {templates.map((t) => (
              <Tr key={t.name}>
                <Td main>{t.name}</Td>
                <Td><CloudBadge cloud={t.cloud} /></Td>
                <Td>{t.category}</Td>
                <Td>{t.resources}</Td>
                <Td>{t.uses.toLocaleString()}</Td>
                <Td className={t.rate < 95 ? "text-amber-400" : "text-green-400"}>{t.rate}%</Td>
                <Td>{t.updated}</Td>
                <Td><StatusPill status={t.status} /></Td>
                <Td><Button variant="ghost" size="sm" className="text-[10px] py-1 px-2">Edit</Button></Td>
              </Tr>
            ))}
          </Table>
        </Card>
      </div>
    </>
  );
}
