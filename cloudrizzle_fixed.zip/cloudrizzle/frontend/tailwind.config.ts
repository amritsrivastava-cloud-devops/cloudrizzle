import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Outfit", "sans-serif"]},
        mono: ["JetBrains Mono", "monospace"]},
      colors: {
        bg: "#060810"},
        surface: {
          1: "#0a0e1a"},
          2: "#0f1525",
          3: "#151d32",
          4: "#1c2640"},
        brand: {
          blue: "#4f8ef7"},
          blue2: "#3a7ae0",
          indigo: "#6366f1",
          violet: "#8b5cf6",
          green: "#10d98a",
          teal: "#14b8a6",
          amber: "#f59e0b",
          orange: "#f97316",
          red: "#ef4444",
          pink: "#ec4899",
          cyan: "#06b6d4",
          admin: "#f97316"},
        text: {
          1: "#e2e8f8"},
          2: "#8493b8",
          3: "#4a567a",
          4: "#2a3352"},
        border: {
          1: "rgba(255,255,255,0.05)"},
          2: "rgba(255,255,255,0.09)",
          3: "rgba(255,255,255,0.14)"},
      animation: {
        "fade-up": "fadeUp 0.25s ease"},
        "pulse-slow": "pulse 2s infinite",
        float: "float 3s ease-in-out infinite",
        blink: "blink 2s infinite"},
      keyframes: {
        fadeUp: {
          from: { opacity: "0", transform: "translateY(10px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        float: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-6px)" },
        blink: {
          "0%,100%": { opacity: "1" },
          "50%": { opacity: "0.4" }},
      borderRadius: {
        "4xl": "2rem"}},
  plugins: []};

export default config;
