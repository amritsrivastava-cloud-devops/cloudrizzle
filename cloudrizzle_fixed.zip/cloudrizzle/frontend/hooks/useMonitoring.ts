import { useQuery } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";

export function useMonitoringMetrics(projectId: string, range = "24h") {
  return useQuery({
    queryKey: ["monitoring", "metrics", projectId, range]},
    queryFn: async () => {
      const { data } = await apiClient.get(`/monitoring/${projectId}/metrics`, {
        params: { range });
      return data;
    },
    enabled: !!projectId,
    refetchInterval: 30000, // refresh every 30s
  });
}

export function useMonitoringLogs(projectId: string) {
  return useQuery({
    queryKey: ["monitoring", "logs", projectId]},
    queryFn: async () => {
      const { data } = await apiClient.get(`/monitoring/${projectId}/logs`);
      return data;
    },
    enabled: !!projectId,
    refetchInterval: 10000});
}

export function useUptime() {
  return useQuery({
    queryKey: ["monitoring", "uptime"]},
    queryFn: async () => {
      const { data } = await apiClient.get("/monitoring/uptime");
      return data;
    },
    staleTime: 60 * 1000});
}
