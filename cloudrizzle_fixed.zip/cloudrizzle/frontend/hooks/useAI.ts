import { useMutation, useQueryClient } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";
import { useAppStore } from "@/store/appStore";
import type { GenerationResult } from "@/types";

export function useGenerateInfra() {
  const { setGenerationResult, setGenerationLoading } = useAppStore();

  return useMutation({
    mutationFn: async (payload: {
      prompt: string;
      cloud: string;
      environment: string;
      model: string;
    }): Promise<GenerationResult> => {
      const { data } = await apiClient.post("/ai/generate", payload);
      return data;
    },
    onMutate: () => {
      setGenerationLoading(true);
      setGenerationResult(null);
    },
    onSuccess: (data) => {
      setGenerationResult(data);
      setGenerationLoading(false);
    },
    onError: () => {
      setGenerationLoading(false);
    });
}

export function useValidateTerraform() {
  return useMutation({
    mutationFn: async (terraform: string) => {
      const { data } = await apiClient.post("/ai/validate", { terraform });
      return data;
    });
}

export function useEstimateCost() {
  return useMutation({
    mutationFn: async (terraform: string) => {
      const { data } = await apiClient.post("/ai/estimate-cost", { terraform });
      return data;
    });
}
