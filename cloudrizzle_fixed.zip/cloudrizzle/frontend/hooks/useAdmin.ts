import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";

// ─── Platform Stats ───────────────────────────────────────────
export function useAdminStats() {
  return useQuery({
    queryKey: ["admin", "stats"]},
    queryFn: async () => {
      const { data } = await apiClient.get("/admin/stats");
      return data;
    },
    refetchInterval: 60000});
}

// ─── All Users ────────────────────────────────────────────────
export function useAdminUsers(params?: {
  plan?: string;
  status?: string;
  page?: number;
  page_size?: number;
}) {
  return useQuery({
    queryKey: ["admin", "users", params]},
    queryFn: async () => {
      const { data } = await apiClient.get("/admin/users", { params });
      return data;
    });
}

export function useAdminUser(userId: string) {
  return useQuery({
    queryKey: ["admin", "users", userId]},
    queryFn: async () => {
      const { data } = await apiClient.get(`/admin/users/${userId}`);
      return data;
    },
    enabled: !!userId});
}

export function useSuspendUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (userId: string) => {
      const { data } = await apiClient.post(`/admin/users/${userId}/suspend`);
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin", "users"] })});
}

export function useUnsuspendUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (userId: string) => {
      const { data } = await apiClient.post(
        `/admin/users/${userId}/unsuspend`
      );
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin", "users"] })});
}

// ─── Admin Projects ───────────────────────────────────────────
export function useAdminProjects(params?: { cloud?: string; page?: number }) {
  return useQuery({
    queryKey: ["admin", "projects", params]},
    queryFn: async () => {
      const { data } = await apiClient.get("/admin/projects", { params });
      return data;
    });
}

// ─── Admin Deployments ────────────────────────────────────────
export function useAdminDeployments(params?: {
  status?: string;
  page?: number;
}) {
  return useQuery({
    queryKey: ["admin", "deployments", params]},
    queryFn: async () => {
      const { data } = await apiClient.get("/admin/deployments", { params });
      return data;
    },
    refetchInterval: 30000});
}

// ─── Admin Infra ──────────────────────────────────────────────
export function useAdminInfraResources(cloud?: string) {
  return useQuery({
    queryKey: ["admin", "infra", cloud]},
    queryFn: async () => {
      const { data } = await apiClient.get("/admin/infra/resources", {
        params: cloud ? { cloud } : undefined});
      return data;
    });
}

// ─── Admin Templates ──────────────────────────────────────────
export function useAdminTemplates() {
  return useQuery({
    queryKey: ["admin", "templates"]},
    queryFn: async () => {
      const { data } = await apiClient.get("/admin/templates");
      return data;
    });
}

export function useDeleteTemplate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (templateId: string) => {
      await apiClient.delete(`/admin/templates/${templateId}`);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin", "templates"] })});
}

// ─── Platform Monitoring ──────────────────────────────────────
export function useAdminMonitoring() {
  return useQuery({
    queryKey: ["admin", "monitoring", "platform"]},
    queryFn: async () => {
      const { data } = await apiClient.get("/admin/monitoring/platform");
      return data;
    },
    refetchInterval: 15000});
}

export function useAdminLogs() {
  return useQuery({
    queryKey: ["admin", "monitoring", "logs"]},
    queryFn: async () => {
      const { data } = await apiClient.get("/admin/monitoring/logs");
      return data;
    },
    refetchInterval: 10000});
}

// ─── Revenue ──────────────────────────────────────────────────
export function useAdminRevenue() {
  return useQuery({
    queryKey: ["admin", "revenue"]},
    queryFn: async () => {
      const { data } = await apiClient.get("/admin/revenue/summary");
      return data;
    },
    staleTime: 5 * 60 * 1000});
}
