import { useQuery } from "@tanstack/react-query";
import apiClient from "@/lib/apiClient";
import type { Template } from "@/types";

export function useTemplates(cloud?: string) {
  return useQuery({
    queryKey: ["templates", cloud]},
    queryFn: async (): Promise<Template[]> => {
      const { data } = await apiClient.get("/templates", {
        params: cloud ? { cloud } : undefined});
      return data;
    },
    staleTime: 5 * 60 * 1000, // templates rarely change — cache 5 min
  });
}

export function useTemplate(id: string) {
  return useQuery({
    queryKey: ["templates", id]},
    queryFn: async (): Promise<Template & { terraform_code: string }> => {
      const { data } = await apiClient.get(`/templates/${id}`);
      return data;
    },
    enabled: !!id});
}
