from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
import httpx
from app.core.config import settings
from app.models.user import User
from app.core.database import get_db
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import structlog

logger = structlog.get_logger()
bearer_scheme = HTTPBearer()

CLERK_JWKS_URL = "https://api.clerk.com/v1/jwks"
_jwks_cache: dict = {}


async def get_jwks() -> dict:
    """Fetch Clerk JWKS (JSON Web Key Set) for token verification."""
    global _jwks_cache
    if _jwks_cache:
        return _jwks_cache
    async with httpx.AsyncClient() as client:
        headers = {"Authorization": f"Bearer {settings.CLERK_SECRET_KEY}"}
        resp = await client.get(CLERK_JWKS_URL, headers=headers)
        resp.raise_for_status()
        _jwks_cache = resp.json()
    return _jwks_cache


async def verify_clerk_token(token: str) -> dict:
    """Verify a Clerk JWT and return its claims."""
    try:
        jwks = await get_jwks()
        # Decode without verification first to get the key ID
        unverified = jwt.get_unverified_header(token)
        kid = unverified.get("kid")

        # Find matching key
        key = next((k for k in jwks.get("keys", []) if k["kid"] == kid), None)
        if not key:
            raise HTTPException(status_code=401, detail="Invalid token: key not found")

        # Verify and decode
        claims = jwt.decode(
            token,
            key,
            algorithms=["RS256"],
            options={"verify_aud": False},
        )
        return claims

    except JWTError as e:
        logger.error("JWT verification failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
        )


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Get current authenticated user from Clerk token."""
    token = credentials.credentials
    claims = await verify_clerk_token(token)

    clerk_user_id = claims.get("sub")
    if not clerk_user_id:
        raise HTTPException(status_code=401, detail="Invalid token: no user ID")

    # Find or create user in our DB
    result = await db.execute(select(User).where(User.clerk_id == clerk_user_id))
    user = result.scalar_one_or_none()

    if not user:
        # Auto-create user on first login
        email = claims.get("email", "")
        name = f"{claims.get('first_name', '')} {claims.get('last_name', '')}".strip()
        user = User(
            clerk_id=clerk_user_id,
            email=email,
            name=name or email,
            role="user",
            plan="free",
            status="active",
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)

    if user.status == "suspended":
        raise HTTPException(status_code=403, detail="Account suspended")

    return user


async def get_admin_user(current_user: User = Depends(get_current_user)) -> User:
    """Require admin role."""
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required",
        )
    return current_user
