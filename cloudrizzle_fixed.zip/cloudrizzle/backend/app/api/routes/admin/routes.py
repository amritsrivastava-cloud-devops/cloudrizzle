from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc
from typing import Optional
from app.core.database import get_db
from app.core.security import get_admin_user
from app.models.user import User, Project, Deployment, InfraResource, Template
from app.schemas.schemas import AdminStatsOut, TemplateOut
import structlog

logger = structlog.get_logger()
router = APIRouter(prefix="/admin", tags=["admin"])


# ─── Platform Stats ───────────────────────────────────────────
@router.get("/stats", response_model=AdminStatsOut)
async def get_platform_stats(admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    total_users = (await db.execute(select(func.count()).select_from(User))).scalar()
    total_projects = (await db.execute(select(func.count()).select_from(Project))).scalar()
    total_deployments = (await db.execute(select(func.count()).select_from(Deployment))).scalar()
    failed_30d = (await db.execute(
        select(func.count()).select_from(Deployment).where(Deployment.status == "failed")
    )).scalar()

    return AdminStatsOut(
        total_users=total_users or 0,
        active_users_today=284,
        total_projects=total_projects or 0,
        total_deployments=total_deployments or 0,
        failed_deployments_30d=failed_30d or 0,
        mrr=28400.0,
        arr=340800.0,
        churn_rate=4.2,
        arpu=22.10,
    )


# ─── Users ────────────────────────────────────────────────────
@router.get("/users")
async def list_all_users(
    plan: Optional[str] = None,
    status: Optional[str] = None,
    page: int = 1,
    page_size: int = 20,
    admin: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    query = select(User)
    if plan:
        query = query.where(User.plan == plan)
    if status:
        query = query.where(User.status == status)
    query = query.order_by(desc(User.created_at)).offset((page - 1) * page_size).limit(page_size)

    result = await db.execute(query)
    users = result.scalars().all()
    total = (await db.execute(select(func.count()).select_from(User))).scalar()

    return {
        "data": [
            {
                "id": u.id, "email": u.email, "name": u.name,
                "role": u.role, "plan": u.plan, "status": u.status,
                "created_at": u.created_at.isoformat(),
                "last_active_at": u.last_active_at.isoformat(),
            }
            for u in users
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total // page_size) + 1,
    }


@router.get("/users/{user_id}")
async def get_user(user_id: str, admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    projects_count = (await db.execute(
        select(func.count()).select_from(Project).where(Project.user_id == user_id)
    )).scalar()
    deploys_count = (await db.execute(
        select(func.count()).select_from(Deployment).where(Deployment.user_id == user_id)
    )).scalar()
    total_spend = (await db.execute(
        select(func.sum(Project.monthly_cost)).where(Project.user_id == user_id)
    )).scalar()

    return {
        **user.__dict__,
        "project_count": projects_count,
        "deployment_count": deploys_count,
        "total_spend": round(float(total_spend or 0), 2),
    }


@router.post("/users/{user_id}/suspend")
async def suspend_user(user_id: str, admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.status = "suspended"
    await db.commit()
    logger.info("User suspended", user_id=user_id, admin_id=admin.id)
    return {"message": "User suspended"}


@router.post("/users/{user_id}/unsuspend")
async def unsuspend_user(user_id: str, admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.status = "active"
    await db.commit()
    return {"message": "User unsuspended"}


# ─── Admin Projects ───────────────────────────────────────────
@router.get("/projects")
async def list_all_projects(
    cloud: Optional[str] = None,
    page: int = 1,
    page_size: int = 20,
    admin: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    query = select(Project)
    if cloud:
        query = query.where(Project.cloud == cloud)
    query = query.order_by(desc(Project.updated_at)).offset((page - 1) * page_size).limit(page_size)

    result = await db.execute(query)
    projects = result.scalars().all()
    total = (await db.execute(select(func.count()).select_from(Project))).scalar()

    return {
        "data": [
            {
                "id": p.id, "name": p.name, "cloud": p.cloud,
                "environment": p.environment, "status": p.status,
                "resource_count": p.resource_count, "monthly_cost": p.monthly_cost,
                "user_id": p.user_id,
                "created_at": p.created_at.isoformat(),
            }
            for p in projects
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


# ─── Admin Deployments ────────────────────────────────────────
@router.get("/deployments")
async def list_all_deployments(
    status: Optional[str] = None,
    page: int = 1,
    page_size: int = 20,
    admin: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    query = select(Deployment)
    if status:
        query = query.where(Deployment.status == status)
    query = query.order_by(desc(Deployment.created_at)).offset((page - 1) * page_size).limit(page_size)

    result = await db.execute(query)
    deployments = result.scalars().all()
    total = (await db.execute(select(func.count()).select_from(Deployment))).scalar()

    return {
        "data": [
            {
                "id": d.id, "project_id": d.project_id, "user_id": d.user_id,
                "version": d.version, "environment": d.environment, "status": d.status,
                "triggered_by": d.triggered_by, "duration_seconds": d.duration_seconds,
                "created_at": d.created_at.isoformat(),
            }
            for d in deployments
        ],
        "total": total,
        "page": page,
    }


# ─── Admin Infra Resources ────────────────────────────────────
@router.get("/infra/resources")
async def list_all_resources(
    cloud: Optional[str] = None,
    admin: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    query = select(InfraResource)
    if cloud:
        query = query.where(InfraResource.cloud == cloud)
    result = await db.execute(query)
    resources = result.scalars().all()
    return {"data": [r.__dict__ for r in resources], "total": len(resources)}


# ─── Admin Templates ──────────────────────────────────────────
@router.get("/templates")
async def list_templates(admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Template).order_by(desc(Template.usage_count)))
    return {"data": result.scalars().all()}


@router.post("/templates", status_code=201)
async def create_template(payload: dict, admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    template = Template(**payload)
    db.add(template)
    await db.commit()
    await db.refresh(template)
    return template


@router.delete("/templates/{template_id}", status_code=204)
async def delete_template(template_id: str, admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Template).where(Template.id == template_id))
    template = result.scalar_one_or_none()
    if not template:
        raise HTTPException(status_code=404, detail="Template not found")
    await db.delete(template)
    await db.commit()


# ─── Admin Monitoring ─────────────────────────────────────────
@router.get("/monitoring/platform")
async def get_platform_monitoring(admin: User = Depends(get_admin_user)):
    return {
        "cpu_percent": 34.0,
        "memory_percent": 58.0,
        "disk_percent": 41.0,
        "network_in_mbps": 124.0,
        "network_out_mbps": 89.0,
        "api_latency_ms": 142.0,
        "active_connections": 284,
        "queue_depth": 47,
        "uptime_percent": 99.2,
        "docker_containers": {"total": 6, "healthy": 6},
        "postgres_connections": {"current": 48, "max": 100},
        "redis_memory_gb": 1.2,
    }


@router.get("/monitoring/logs")
async def get_platform_logs(admin: User = Depends(get_admin_user)):
    return {
        "logs": [
            {"ts": "14:32:01", "lvl": "INFO", "msg": "Temporal workflow deploy#987688 started"},
            {"ts": "14:31:58", "lvl": "INFO", "msg": "User authenticated via Clerk"},
            {"ts": "14:31:44", "lvl": "WARN", "msg": "PostgreSQL pool 48/100 connections"},
            {"ts": "14:31:32", "lvl": "ERROR", "msg": "Azure AKS deploy#654321 timeout 8m34s"},
            {"ts": "14:30:17", "lvl": "INFO", "msg": "AI Generator: Terraform validated OK"},
            {"ts": "14:29:55", "lvl": "INFO", "msg": "Redis cache hit rate: 94.2%"},
        ]
    }


# ─── Admin Revenue ────────────────────────────────────────────
@router.get("/revenue/summary")
async def get_revenue_summary(admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    return {
        "mrr": 28400.0,
        "arr": 340800.0,
        "churn_rate": 4.2,
        "arpu": 22.10,
        "by_plan": {
            "enterprise": 18200.0,
            "pro": 10200.0,
            "free": 0.0,
        },
        "growth_mom": 11.0,
    }
